/* ============================================================
   SafeGrid Africa — SafetyScore
   Floating map overlay showing area safety score and trend.
   ============================================================ */

import React, { useState } from 'react';
import { AREA_SCORES } from '../data/mockData';
import { getSafetyScore } from '../utils/helpers';

function TrendArrow({ trend }) {
  if (trend === 'improving') return <span style={{ color: '#00F5A0', fontSize: '11px' }}>▲ Improving</span>;
  if (trend === 'declining') return <span style={{ color: '#FF6B6B', fontSize: '11px' }}>▼ Declining</span>;
  return <span style={{ color: '#9BB8D4', fontSize: '11px' }}>→ Stable</span>;
}

function SafetyScore({ area = 'Westlands' }) {
  const [expanded, setExpanded] = useState(false);
  const { score, label, color, trend } = getSafetyScore(area);
  const pct = Math.round((score / 10) * 100);

  return (
    <div
      style={{
        position: 'absolute',
        left: '16px',
        bottom: '96px',
        zIndex: 20,
        background: 'rgba(15,38,84,0.92)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        border: '1px solid rgba(0,174,239,0.32)',
        borderRadius: '16px',
        padding: expanded ? '14px 16px' : '10px 14px',
        minWidth: '148px',
        cursor: 'pointer',
        transition: 'all 0.3s cubic-bezier(0.4,0,0.2,1)',
        userSelect: 'none',
      }}
      onClick={() => setExpanded((e) => !e)}
      role="button"
      aria-label={`Safety score for ${area}: ${score.toFixed(1)} — ${label}`}
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && setExpanded((x) => !x)}
    >
      {/* Header row */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '4px' }}>
        <div style={{ fontSize: '9px', fontWeight: 700, letterSpacing: '1px', color: 'var(--text-3)', textTransform: 'uppercase' }}>
          Safety Score
        </div>
        <div style={{ fontSize: '10px', color: 'var(--text-3)' }}>{expanded ? '▲' : '▼'}</div>
      </div>

      {/* Score number */}
      <div style={{ display: 'flex', alignItems: 'baseline', gap: '4px' }}>
        <div style={{
          fontFamily: 'var(--font-display)',
          fontSize: '30px',
          fontWeight: 800,
          color,
          lineHeight: 1,
          letterSpacing: '-1px',
        }}>
          {score.toFixed(1)}
        </div>
        <div style={{ fontSize: '11px', color: 'var(--text-3)' }}>/10</div>
      </div>

      {/* Label */}
      <div style={{ fontSize: '11px', color, fontWeight: 600, marginTop: '2px' }}>{label}</div>

      {/* Score bar */}
      <div style={{
        height: '4px', borderRadius: '2px',
        background: 'rgba(255,255,255,0.1)',
        marginTop: '8px', overflow: 'hidden',
      }}>
        <div style={{
          height: '100%',
          borderRadius: '2px',
          width: `${pct}%`,
          background: `linear-gradient(90deg, #FF3B3B, #FF9A00, #00F5A0)`,
          transition: 'width 0.8s cubic-bezier(0.4,0,0.2,1)',
        }} />
      </div>

      {/* Expanded: nearby areas */}
      {expanded && (
        <div style={{ marginTop: '12px', borderTop: '1px solid rgba(0,174,239,0.15)', paddingTop: '10px' }}>
          <div style={{ fontSize: '10px', fontWeight: 700, color: 'var(--text-3)', letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: '8px' }}>
            Nearby Areas
          </div>
          {Object.entries(AREA_SCORES)
            .sort((a, b) => b[1].score - a[1].score)
            .slice(0, 5)
            .map(([areaName, data]) => {
              const { color: aColor } = getSafetyScore(areaName);
              return (
                <div key={areaName} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <span style={{ fontSize: '11px', color: 'var(--text-2)' }}>{areaName}</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <TrendArrow trend={data.trend} />
                    <span style={{ fontSize: '12px', fontWeight: 700, color: aColor, minWidth: '28px', textAlign: 'right' }}>
                      {data.score.toFixed(1)}
                    </span>
                  </div>
                </div>
              );
            })}
        </div>
      )}
    </div>
  );
}

export default SafetyScore;
