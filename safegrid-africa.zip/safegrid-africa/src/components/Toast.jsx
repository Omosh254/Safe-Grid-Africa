/* ============================================================
   SafeGrid Africa — Toast
   Lightweight, accessible toast notifications.
   ============================================================ */

import React, { useState, useEffect, useCallback, useRef } from 'react';

const TOAST_TYPES = {
  info:    { bg: 'rgba(0,174,239,0.15)',  border: 'rgba(0,174,239,0.4)',   icon: 'ℹ️' },
  success: { bg: 'rgba(0,245,160,0.12)',  border: 'rgba(0,245,160,0.35)',  icon: '✅' },
  warning: { bg: 'rgba(255,154,0,0.12)',  border: 'rgba(255,154,0,0.35)',  icon: '⚠️' },
  error:   { bg: 'rgba(255,59,59,0.14)',  border: 'rgba(255,59,59,0.4)',   icon: '❌' },
};

// ── Toast Item ────────────────────────────────────────────────
function ToastItem({ toast, onDismiss }) {
  const { bg, border, icon } = TOAST_TYPES[toast.type] || TOAST_TYPES.info;
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Tiny delay to trigger entrance animation
    const tid = setTimeout(() => setVisible(true), 10);
    return () => clearTimeout(tid);
  }, []);

  function handleDismiss() {
    setVisible(false);
    setTimeout(() => onDismiss(toast.id), 250);
  }

  return (
    <div
      role="alert"
      aria-live="polite"
      style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '10px',
        padding: '12px 14px',
        borderRadius: '12px',
        background: bg,
        border: `1px solid ${border}`,
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
        maxWidth: '340px',
        width: 'calc(100vw - 40px)',
        transition: 'all 0.25s cubic-bezier(0.4,0,0.2,1)',
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0) scale(1)' : 'translateY(-8px) scale(0.95)',
        marginBottom: '8px',
      }}
    >
      <span style={{ fontSize: '16px', flexShrink: 0, lineHeight: 1.3 }}>{icon}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        {toast.title && (
          <div style={{ fontWeight: 700, fontSize: '13px', marginBottom: '2px' }}>
            {toast.title}
          </div>
        )}
        <div style={{ fontSize: '12px', color: 'var(--text-2)', lineHeight: 1.4 }}>
          {toast.message}
        </div>
      </div>
      <button
        onClick={handleDismiss}
        aria-label="Dismiss notification"
        style={{
          width: '20px', height: '20px',
          borderRadius: '6px',
          background: 'rgba(255,255,255,0.1)',
          border: 'none',
          color: 'var(--text-2)',
          cursor: 'pointer',
          fontSize: '11px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        ✕
      </button>
    </div>
  );
}

// ── Toast Container ───────────────────────────────────────────
function ToastContainer({ toasts, onDismiss }) {
  if (!toasts.length) return null;

  return (
    <div
      style={{
        position: 'fixed',
        top: '60px',
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 300,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        pointerEvents: 'none',
      }}
      aria-label="Notifications"
    >
      {toasts.map((t) => (
        <div key={t.id} style={{ pointerEvents: 'all' }}>
          <ToastItem toast={t} onDismiss={onDismiss} />
        </div>
      ))}
    </div>
  );
}

// ── useToast Hook ─────────────────────────────────────────────
let _toastId = 0;

export function useToast() {
  const [toasts, setToasts] = useState([]);
  const timersRef = useRef({});

  const dismiss = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
    clearTimeout(timersRef.current[id]);
    delete timersRef.current[id];
  }, []);

  const show = useCallback(
    (message, { title, type = 'info', duration = 3500 } = {}) => {
      const id = ++_toastId;
      setToasts((prev) => [...prev.slice(-3), { id, message, title, type }]);
      timersRef.current[id] = setTimeout(() => dismiss(id), duration);
      return id;
    },
    [dismiss]
  );

  // Convenience methods
  const info    = useCallback((msg, opts) => show(msg, { ...opts, type: 'info'    }), [show]);
  const success = useCallback((msg, opts) => show(msg, { ...opts, type: 'success' }), [show]);
  const warning = useCallback((msg, opts) => show(msg, { ...opts, type: 'warning' }), [show]);
  const error   = useCallback((msg, opts) => show(msg, { ...opts, type: 'error'   }), [show]);

  const Toasts = useCallback(
    () => <ToastContainer toasts={toasts} onDismiss={dismiss} />,
    [toasts, dismiss]
  );

  return { show, info, success, warning, error, dismiss, Toasts };
}

export default ToastContainer;
