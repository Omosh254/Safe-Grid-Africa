/* ============================================================
   SafeGrid Africa — AlertsPanel
   Displays active safety alerts, stats, and area safety scores.
   ============================================================ */

import React, { useState } from 'react';
import { MOCK_ALERTS, MOCK_CRIMES } from '../data/mockData';
import { alertLevelColor, getSafetyScore } from '../utils/helpers';

const LEVEL_LABELS = { high: '🔴 HIGH RISK', medium: '🟡 MEDIUM RISK', low: '🟢 LOW RISK' };

function StatCard({ value, label, color }) {
  return (
    <div style={{
      background: 'rgba(255,255,255,0.04)',
      border: '1px solid var(--border)',
      borderRadius: '10px',
      padding: '12px',
      textAlign: 'center',
    }}>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: '26px', fontWeight: 800, color, lineHeight: 1 }}>
        {value}
      </div>
      <div style={{ fontSize: '10px', color: 'var(--text-3)', marginTop: '4px', lineHeight: 1.3 }}>
        {label}
      </div>
    </div>
  );
}

function AlertCard({ alert, onFocus }) {
  const borderColor = alertLevelColor(alert.level);
  return (
    <div
      style={{
        padding: '12px',
        borderRadius: '10px',
        marginBottom: '8px',
        borderLeft: `3px solid ${borderColor}`,
        background: 'rgba(255,255,255,0.03)',
        cursor: 'pointer',
        transition: 'background 0.2s',
      }}
      onClick={() => onFocus?.(alert)}
      onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(255,255,255,0.07)')}
      onMouseLeave={(e) => (e.currentTarget.style.background = 'rgba(255,255,255,0.03)')}
      role="button"
      tabIndex={0}
      aria-label={`${alert.level} alert: ${alert.title}`}
    >
      <div style={{
        fontSize: '9px', fontWeight: 700, letterSpacing: '1px',
        color: borderColor, marginBottom: '4px',
      }}>
        {LEVEL_LABELS[alert.level]} — {alert.area}
      </div>
      <div style={{ fontSize: '13px', fontWeight: 600, marginBottom: '4px', lineHeight: 1.3 }}>
        {alert.title}
      </div>
      <div style={{ fontSize: '12px', color: 'var(--text-2)', lineHeight: 1.5, marginBottom: '6px' }}>
        {alert.message}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: '11px', color: 'var(--text-3)' }}>{alert.time}</span>
        <span style={{ fontSize: '10px', color: 'var(--text-3)', background: 'rgba(255,255,255,0.06)', padding: '2px 6px', borderRadius: '4px' }}>
          {alert.source}
        </span>
      </div>
    </div>
  );
}

function AlertsPanel({ onAlertFocus }) {
  const [activeLevel, setActiveLevel] = useState('all');

  const total      = MOCK_CRIMES.length;
  const verified   = MOCK_CRIMES.filter((c) => c.status === 'Verified').length;
  const highRisk   = MOCK_CRIMES.filter((c) => c.severity === 'high').length;
  const { score, label, color } = getSafetyScore('Westlands');

  const filtered = activeLevel === 'all'
    ? MOCK_ALERTS
    : MOCK_ALERTS.filter((a) => a.level === activeLevel);

  return (
    <div>
      {/* Stats Row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '16px' }}>
        <StatCard value={total}     label="Total Incidents"   color="var(--danger-soft)" />
        <StatCard value={highRisk}  label="High Risk"         color="var(--warning)" />
        <StatCard value={verified}  label="Verified Reports"  color="var(--secondary)" />
        <StatCard value={score.toFixed(1)} label="Area Safety Score" color={color} />
      </div>

      {/* Area Score Bar */}
      <div style={{
        background: 'rgba(255,255,255,0.04)',
        border: '1px solid var(--border)',
        borderRadius: '10px',
        padding: '12px',
        marginBottom: '16px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
          <div style={{ fontSize: '12px', fontWeight: 600 }}>Westlands Safety Index</div>
          <div style={{ fontSize: '12px', color, fontWeight: 700 }}>{label}</div>
        </div>
        <div style={{ height: '6px', borderRadius: '3px', background: 'rgba(255,255,255,0.1)', overflow: 'hidden' }}>
          <div style={{
            height: '100%', borderRadius: '3px',
            width: `${(score / 10) * 100}%`,
            background: `linear-gradient(90deg, var(--danger), var(--warning), var(--accent))`,
            transition: 'width 0.8s cubic-bezier(0.4,0,0.2,1)',
          }} />
        </div>
        <div style={{ fontSize: '10px', color: 'var(--text-3)', marginTop: '6px' }}>
          Based on {total} incidents in the last 30 days
        </div>
      </div>

      {/* Level Filter Tabs */}
      <div style={{ display: 'flex', gap: '6px', marginBottom: '12px' }}>
        {['all', 'high', 'medium', 'low'].map((lvl) => (
          <button
            key={lvl}
            onClick={() => setActiveLevel(lvl)}
            style={{
              padding: '5px 10px',
              borderRadius: '20px',
              fontSize: '11px',
              fontWeight: 600,
              cursor: 'pointer',
              border: `1px solid ${activeLevel === lvl ? alertLevelColor(lvl === 'all' ? 'low' : lvl) : 'var(--border)'}`,
              background: activeLevel === lvl ? `${alertLevelColor(lvl === 'all' ? 'low' : lvl)}20` : 'transparent',
              color: activeLevel === lvl ? alertLevelColor(lvl === 'all' ? 'low' : lvl) : 'var(--text-3)',
              transition: 'all 0.2s',
              textTransform: 'capitalize',
            }}
          >
            {lvl === 'all' ? 'All' : lvl}
            {lvl !== 'all' && (
              <span style={{ marginLeft: '4px', opacity: 0.7 }}>
                ({MOCK_ALERTS.filter((a) => a.level === lvl).length})
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Alert Cards */}
      <div style={{ fontSize: '11px', fontWeight: 700, letterSpacing: '0.5px', color: 'var(--text-3)', textTransform: 'uppercase', marginBottom: '8px' }}>
        Active Alerts ({filtered.length})
      </div>
      {filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '24px', color: 'var(--text-3)', fontSize: '13px' }}>
          No alerts for this level
        </div>
      ) : (
        filtered.map((a) => (
          <AlertCard key={a.id} alert={a} onFocus={onAlertFocus} />
        ))
      )}
    </div>
  );
}

export default AlertsPanel;
