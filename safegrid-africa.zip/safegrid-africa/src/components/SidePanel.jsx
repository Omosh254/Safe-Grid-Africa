/* ============================================================
   SafeGrid Africa — SidePanel
   Tabbed panel: Alerts, Filters, Sponsored Partners.
   ============================================================ */

import React from 'react';
import AlertsPanel    from './AlertsPanel';
import FiltersPanel   from './FiltersPanel';
import SponsoredPanel from './SponsoredPanel';

const TABS = [
  { id: 'alerts',    icon: '🔔', label: 'Alerts'   },
  { id: 'filters',   icon: '⚙',  label: 'Filters'  },
  { id: 'sponsored', icon: '★',  label: 'Partners' },
];

function SidePanel({ activeTab, setActiveTab, filterProps, onAlertFocus, alertCount = 0, isMobile, isOpen }) {
  const panelStyle = {
    width: '300px',
    flexShrink: 0,
    background: 'rgba(15,38,84,0.94)',
    backdropFilter: 'blur(16px)',
    WebkitBackdropFilter: 'blur(16px)',
    borderLeft: '1px solid rgba(0,174,239,0.18)',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    transition: 'transform 0.32s cubic-bezier(0.4,0,0.2,1)',
    ...(isMobile
      ? {
          position: 'absolute',
          right: 0,
          top: 0,
          bottom: 0,
          zIndex: 40,
          transform: isOpen ? 'translateX(0)' : 'translateX(100%)',
        }
      : {}),
  };

  return (
    <div style={panelStyle} aria-hidden={isMobile && !isOpen}>
      {/* Tab bar */}
      <div style={{
        display: 'flex',
        borderBottom: '1px solid rgba(0,174,239,0.18)',
        flexShrink: 0,
      }}>
        {TABS.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              aria-selected={isActive}
              role="tab"
              style={{
                flex: 1,
                padding: '11px 6px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '3px',
                border: 'none',
                background: 'none',
                color: isActive ? 'var(--secondary)' : 'var(--text-3)',
                cursor: 'pointer',
                fontFamily: 'var(--font-body)',
                fontSize: '10px',
                fontWeight: 700,
                letterSpacing: '0.3px',
                position: 'relative',
                transition: 'color 0.2s',
              }}
            >
              {/* Active indicator bar */}
              {isActive && (
                <div style={{
                  position: 'absolute',
                  bottom: 0, left: 0, right: 0,
                  height: '2px',
                  background: 'var(--secondary)',
                  borderRadius: '2px 2px 0 0',
                }} />
              )}
              <span style={{ fontSize: '16px', lineHeight: 1 }}>{tab.icon}</span>
              <span>{tab.label}</span>
              {/* Alert badge */}
              {tab.id === 'alerts' && alertCount > 0 && (
                <div style={{
                  position: 'absolute',
                  top: '6px',
                  right: '18px',
                  width: '16px',
                  height: '16px',
                  borderRadius: '50%',
                  background: 'var(--danger)',
                  color: 'white',
                  fontSize: '9px',
                  fontWeight: 800,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                  {alertCount > 9 ? '9+' : alertCount}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Panel body */}
      <div style={{
        flex: 1,
        overflowY: 'auto',
        padding: '14px',
        scrollbarWidth: 'thin',
        scrollbarColor: 'rgba(0,174,239,0.3) transparent',
      }}
        role="tabpanel"
        aria-label={`${activeTab} panel`}
      >
        {activeTab === 'alerts'    && <AlertsPanel    onAlertFocus={onAlertFocus} />}
        {activeTab === 'filters'   && <FiltersPanel   {...filterProps} />}
        {activeTab === 'sponsored' && <SponsoredPanel />}
      </div>
    </div>
  );
}

export default SidePanel;
