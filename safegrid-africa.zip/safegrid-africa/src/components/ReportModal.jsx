/* ============================================================
   SafeGrid Africa — ReportModal
   Slide-up modal for submitting new incident reports.
   INSERT BACKEND API ENDPOINT HERE — see src/utils/api.js
   INSERT AUTH LOGIC HERE — require login before submission
   INSERT IMAGE/ICON URL HERE — for evidence upload preview
   ============================================================ */

import React, { useState, useRef, useEffect } from 'react';
import { submitIncident, uploadEvidence } from '../utils/api';
import { formatCoords } from '../utils/helpers';
import useGeolocation from '../hooks/useGeolocation';

const INCIDENT_TYPES = [
  'Theft', 'Robbery', 'Assault', 'Carjacking', 'Burglary',
  'Vandalism', 'Fraud', 'Harassment', 'Suspicious Activity', 'Other',
];

const STEPS = {
  FORM:    'form',
  LOADING: 'loading',
  SUCCESS: 'success',
  ERROR:   'error',
};

function ReportModal({ onClose }) {
  const [step, setStep]       = useState(STEPS.FORM);
  const [errorMsg, setError]  = useState('');
  const [preview, setPreview] = useState(null); // Image preview URL
  const fileInputRef          = useRef(null);
  const modalRef              = useRef(null);
  const { position, loading: gpsLoading, refresh: getGPS } = useGeolocation(false);

  const [form, setForm] = useState({
    type:        '',
    description: '',
    lat:         '',
    lng:         '',
    address:     '',
    date:        new Date().toISOString().split('T')[0],
    time:        new Date().toTimeString().slice(0, 5),
    severity:    'medium',
    file:        null,
  });

  // Auto-fill coordinates when GPS resolves
  useEffect(() => {
    if (position) {
      setForm((f) => ({
        ...f,
        lat:     String(position.lat),
        lng:     String(position.lng),
        address: formatCoords(position.lat, position.lng),
      }));
    }
  }, [position]);

  // Trap focus inside modal
  useEffect(() => {
    const el = modalRef.current;
    if (!el) return;
    const focusables = el.querySelectorAll('button,input,select,textarea,[tabindex]');
    focusables[0]?.focus();

    function trapTab(e) {
      if (e.key !== 'Tab') return;
      const first = focusables[0];
      const last  = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
    el.addEventListener('keydown', trapTab);
    return () => el.removeEventListener('keydown', trapTab);
  }, [step]);

  // Close on Escape
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  function handleChange(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function handleFileChange(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setForm((f) => ({ ...f, file }));
    // INSERT IMAGE/ICON URL HERE — preview uses object URL
    const url = URL.createObjectURL(file);
    setPreview(url);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.type) return;

    setStep(STEPS.LOADING);

    try {
      // INSERT AUTH LOGIC HERE — verify user is authenticated
      // const user = await checkAuth();
      // if (!user) throw new Error('Please log in to submit a report.');

      // INSERT BACKEND API ENDPOINT HERE — see src/utils/api.js submitIncident()
      const payload = {
        type:        form.type,
        description: form.description,
        lat:         parseFloat(form.lat) || null,
        lng:         parseFloat(form.lng) || null,
        address:     form.address,
        date:        form.date,
        time:        form.time,
        severity:    form.severity,
        status:      'Unverified',
      };

      // Simulate API call — replace with: await submitIncident(payload);
      await new Promise((res) => setTimeout(res, 1800));
      // const result = await submitIncident(payload);

      // If a file was attached, upload it
      if (form.file) {
        // await uploadEvidence(result.id, form.file);
        // INSERT IMAGE/ICON URL HERE
      }

      setStep(STEPS.SUCCESS);
    } catch (err) {
      console.error('[SafeGrid] Report submission failed:', err);
      setError(err.message || 'Submission failed. Please try again.');
      setStep(STEPS.ERROR);
    }
  }

  // ── Overlay backdrop
  function handleBackdropClick(e) {
    if (e.target === e.currentTarget) onClose();
  }

  // ── RENDER: Success ───────────────────────────────────────
  if (step === STEPS.SUCCESS) {
    return (
      <div
        style={styles.overlay}
        onClick={handleBackdropClick}
        role="dialog"
        aria-modal="true"
        aria-label="Report submitted"
      >
        <div style={styles.modal} ref={modalRef}>
          <div style={styles.handle} />
          <div style={styles.successContainer}>
            <div style={styles.successIcon}>✅</div>
            <div style={styles.successTitle}>Report Submitted</div>
            <div style={styles.successDesc}>
              Your incident has been received and will be reviewed by our team within 2 hours.
              Thank you for helping keep Nairobi safer.
            </div>
            <button className="sg-btn sg-btn-primary" style={{ width: '100%', marginTop: '20px', padding: '14px' }} onClick={onClose}>
              Back to Map
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── RENDER: Error ─────────────────────────────────────────
  if (step === STEPS.ERROR) {
    return (
      <div style={styles.overlay} onClick={handleBackdropClick} role="dialog" aria-modal="true">
        <div style={styles.modal} ref={modalRef}>
          <div style={styles.handle} />
          <div style={styles.successContainer}>
            <div style={styles.successIcon}>❌</div>
            <div style={{ ...styles.successTitle, color: 'var(--danger-soft)' }}>Submission Failed</div>
            <div style={styles.successDesc}>{errorMsg}</div>
            <div style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
              <button className="sg-btn sg-btn-ghost" style={{ flex: 1 }} onClick={onClose}>Dismiss</button>
              <button className="sg-btn sg-btn-primary" style={{ flex: 1 }} onClick={() => setStep(STEPS.FORM)}>Try Again</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── RENDER: Loading ───────────────────────────────────────
  if (step === STEPS.LOADING) {
    return (
      <div style={styles.overlay} role="dialog" aria-modal="true" aria-label="Submitting report">
        <div style={styles.modal} ref={modalRef}>
          <div style={styles.handle} />
          <div style={styles.successContainer}>
            <div style={{ width: '48px', height: '48px', borderRadius: '50%', border: '4px solid rgba(255,59,59,0.2)', borderTopColor: 'var(--danger)', animation: 'spin 0.8s linear infinite', margin: '0 auto 20px' }} />
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '18px', fontWeight: 700 }}>Submitting Report…</div>
            <div style={{ fontSize: '13px', color: 'var(--text-2)', marginTop: '8px' }}>Please wait while we securely send your report.</div>
            <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
          </div>
        </div>
      </div>
    );
  }

  // ── RENDER: Form ──────────────────────────────────────────
  return (
    <div
      style={styles.overlay}
      onClick={handleBackdropClick}
      role="dialog"
      aria-modal="true"
      aria-label="Report an incident"
    >
      <div style={styles.modal} ref={modalRef}>
        <div style={styles.handle} />

        {/* Header */}
        <div style={styles.header}>
          <div>
            <div style={styles.title}>🚨 Report Incident</div>
            <div style={{ fontSize: '12px', color: 'var(--text-3)', marginTop: '3px' }}>Help your community stay safe</div>
          </div>
          <button
            style={styles.closeBtn}
            onClick={onClose}
            aria-label="Close modal"
          >✕</button>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Incident Type */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Incident Type *</label>
            <select
              className="sg-select"
              value={form.type}
              onChange={(e) => handleChange('type', e.target.value)}
              required
              aria-required="true"
            >
              <option value="">Select incident type…</option>
              {INCIDENT_TYPES.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          {/* Severity */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Perceived Severity</label>
            <div style={{ display: 'flex', gap: '8px' }}>
              {['low', 'medium', 'high'].map((s) => {
                const colors = { low: '#FFD93D', medium: '#FF9A00', high: '#FF3B3B' };
                const active = form.severity === s;
                return (
                  <button
                    key={s}
                    type="button"
                    onClick={() => handleChange('severity', s)}
                    style={{
                      flex: 1,
                      padding: '8px',
                      borderRadius: '8px',
                      border: `1px solid ${active ? colors[s] : 'var(--border)'}`,
                      background: active ? `${colors[s]}20` : 'transparent',
                      color: active ? colors[s] : 'var(--text-2)',
                      fontFamily: 'var(--font-body)',
                      fontWeight: 600,
                      fontSize: '12px',
                      cursor: 'pointer',
                      textTransform: 'capitalize',
                      transition: 'all 0.2s',
                    }}
                  >{s}</button>
                );
              })}
            </div>
          </div>

          {/* Description */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Description *</label>
            <textarea
              className="sg-textarea"
              placeholder="What happened? Describe suspects, vehicle, direction of travel…"
              value={form.description}
              onChange={(e) => handleChange('description', e.target.value)}
              required
              aria-required="true"
              minLength={20}
            />
          </div>

          {/* Location */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Location</label>
            <div style={{ display: 'flex', gap: '8px' }}>
              <input
                className="sg-input"
                placeholder="Address or area name…"
                value={form.address}
                onChange={(e) => handleChange('address', e.target.value)}
                style={{ flex: 1 }}
              />
              <button
                type="button"
                className="sg-btn sg-btn-secondary"
                style={{ flexShrink: 0, padding: '10px 14px' }}
                onClick={getGPS}
                disabled={gpsLoading}
                aria-label="Get my GPS location"
              >
                {gpsLoading ? '…' : '📍 GPS'}
              </button>
            </div>
            {form.lat && (
              <div style={{ fontSize: '11px', color: 'var(--text-3)', marginTop: '4px' }}>
                📌 {formatCoords(parseFloat(form.lat), parseFloat(form.lng))}
              </div>
            )}
          </div>

          {/* Date / Time */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '16px' }}>
            <div>
              <label style={styles.label}>Date</label>
              <input
                type="date"
                className="sg-input"
                value={form.date}
                onChange={(e) => handleChange('date', e.target.value)}
                max={new Date().toISOString().split('T')[0]}
              />
            </div>
            <div>
              <label style={styles.label}>Approx. Time</label>
              <input
                type="time"
                className="sg-input"
                value={form.time}
                onChange={(e) => handleChange('time', e.target.value)}
              />
            </div>
          </div>

          {/* Evidence Upload */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Evidence (optional)</label>
            {preview ? (
              <div style={{ position: 'relative', borderRadius: '10px', overflow: 'hidden', marginBottom: '4px' }}>
                {/* INSERT IMAGE/ICON URL HERE — preview renders uploaded image */}
                <img src={preview} alt="Evidence preview" style={{ width: '100%', height: '140px', objectFit: 'cover' }} />
                <button
                  type="button"
                  onClick={() => { setPreview(null); handleChange('file', null); }}
                  style={{
                    position: 'absolute', top: '8px', right: '8px',
                    background: 'rgba(0,0,0,0.6)', border: 'none', borderRadius: '6px',
                    color: 'white', padding: '4px 8px', cursor: 'pointer', fontSize: '11px',
                  }}
                >Remove</button>
              </div>
            ) : (
              <div
                style={styles.uploadZone}
                onClick={() => fileInputRef.current?.click()}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === 'Enter' && fileInputRef.current?.click()}
                aria-label="Upload evidence photo or video"
              >
                <div style={{ fontSize: '28px', marginBottom: '8px' }}>📷</div>
                <div style={{ fontSize: '13px', fontWeight: 500 }}>Tap to upload photo or video</div>
                <div style={{ fontSize: '11px', color: 'var(--text-3)', marginTop: '4px' }}>
                  JPG, PNG, MP4 · Max 10MB
                </div>
                {/* INSERT IMAGE/ICON URL HERE for custom upload icon */}
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*"
              style={{ display: 'none' }}
              onChange={handleFileChange}
              aria-label="Select evidence file"
            />
          </div>

          {/* Legal disclaimer */}
          <div style={styles.disclaimer}>
            ⚠️ False reports are a criminal offence under the Kenya Penal Code. All submissions are logged with your IP address.
            {/* INSERT AUTH LOGIC HERE — display user identity if logged in */}
          </div>

          {/* Submit */}
          <button
            type="submit"
            className="sg-btn sg-btn-primary"
            style={{ width: '100%', padding: '14px', fontSize: '15px' }}
            disabled={!form.type || !form.description}
          >
            Submit Report
          </button>
        </form>
      </div>
    </div>
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    inset: 0,
    zIndex: 200,
    background: 'rgba(5,15,35,0.88)',
    backdropFilter: 'blur(6px)',
    display: 'flex',
    alignItems: 'flex-end',
    justifyContent: 'center',
    animation: 'fadeIn 0.2s ease-out',
  },
  modal: {
    background: 'var(--surface)',
    border: '1px solid var(--border-2)',
    borderRadius: '24px 24px 0 0',
    width: '100%',
    maxWidth: '520px',
    maxHeight: '92vh',
    overflowY: 'auto',
    padding: '20px 20px 32px',
    animation: 'slideUp 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
  },
  handle: {
    width: '40px', height: '4px', borderRadius: '2px',
    background: 'rgba(255,255,255,0.15)', margin: '0 auto 20px',
  },
  header: {
    display: 'flex', alignItems: 'flex-start',
    justifyContent: 'space-between', marginBottom: '20px',
  },
  title: {
    fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 800,
  },
  closeBtn: {
    width: '32px', height: '32px', borderRadius: '10px',
    background: 'rgba(255,255,255,0.08)', border: 'none',
    color: 'var(--text-2)', cursor: 'pointer', fontSize: '14px',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    flexShrink: 0,
  },
  formGroup: { marginBottom: '16px' },
  label: {
    display: 'block', fontSize: '12px', fontWeight: 600,
    color: 'var(--text-2)', marginBottom: '6px', letterSpacing: '0.3px',
  },
  uploadZone: {
    border: '2px dashed var(--border)', borderRadius: '12px',
    padding: '24px', textAlign: 'center', cursor: 'pointer',
    transition: 'all 0.2s', color: 'var(--text-3)',
  },
  disclaimer: {
    fontSize: '11px', color: 'var(--text-3)', lineHeight: 1.5,
    padding: '10px 12px', background: 'rgba(255,255,255,0.04)',
    borderRadius: '8px', border: '1px solid var(--border)',
    marginBottom: '14px',
  },
  successContainer: { textAlign: 'center', padding: '12px 8px 8px' },
  successIcon:  { fontSize: '52px', marginBottom: '16px' },
  successTitle: { fontFamily: 'var(--font-display)', fontSize: '22px', fontWeight: 800, marginBottom: '10px', color: 'var(--accent)' },
  successDesc:  { fontSize: '14px', color: 'var(--text-2)', lineHeight: 1.6 },
};

export default ReportModal;
