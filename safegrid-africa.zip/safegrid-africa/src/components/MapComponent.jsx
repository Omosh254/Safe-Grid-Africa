/* ============================================================
   SafeGrid Africa — MapComponent
   Full Google Maps JavaScript API integration with custom markers,
   info windows, dark map style, and geolocation support.
   INSERT GOOGLE MAPS API KEY HERE in src/hooks/useGoogleMaps.js
   ============================================================ */

import React, { useEffect, useRef, useCallback } from 'react';
import { useGoogleMaps } from '../hooks/useGoogleMaps';
import { NAIROBI_CENTER, NAIROBI_ZOOM } from '../data/mockData';
import { createMarkerIcon, severityColors } from '../utils/helpers';

// ── Dark map style to match SafeGrid's dark UI ───────────────
// Generated via: https://mapstyle.withgoogle.com/
const DARK_MAP_STYLE = [
  { elementType: 'geometry',                  stylers: [{ color: '#0d1b3e' }] },
  { elementType: 'labels.text.stroke',        stylers: [{ color: '#0d1b3e' }] },
  { elementType: 'labels.text.fill',          stylers: [{ color: '#6a90b0' }] },
  { featureType: 'administrative.locality',   elementType: 'labels.text.fill',   stylers: [{ color: '#9bb8d4' }] },
  { featureType: 'poi',                       elementType: 'labels.text.fill',   stylers: [{ color: '#6a90b0' }] },
  { featureType: 'poi.park',                  elementType: 'geometry',           stylers: [{ color: '#0a2a1a' }] },
  { featureType: 'poi.park',                  elementType: 'labels.text.fill',   stylers: [{ color: '#2a5c3a' }] },
  { featureType: 'road',                      elementType: 'geometry',           stylers: [{ color: '#122248' }] },
  { featureType: 'road',                      elementType: 'geometry.stroke',    stylers: [{ color: '#0a1a38' }] },
  { featureType: 'road',                      elementType: 'labels.text.fill',   stylers: [{ color: '#5a7a9a' }] },
  { featureType: 'road.highway',              elementType: 'geometry',           stylers: [{ color: '#1a3060' }] },
  { featureType: 'road.highway',              elementType: 'geometry.stroke',    stylers: [{ color: '#0e2248' }] },
  { featureType: 'road.highway',              elementType: 'labels.text.fill',   stylers: [{ color: '#7a9cc0' }] },
  { featureType: 'transit',                   elementType: 'geometry',           stylers: [{ color: '#0a1830' }] },
  { featureType: 'transit.station',           elementType: 'labels.text.fill',   stylers: [{ color: '#6a90b0' }] },
  { featureType: 'water',                     elementType: 'geometry',           stylers: [{ color: '#061020' }] },
  { featureType: 'water',                     elementType: 'labels.text.fill',   stylers: [{ color: '#2a4a6a' }] },
  { featureType: 'water',                     elementType: 'labels.text.stroke', stylers: [{ color: '#061020' }] },
];

// ── Info window HTML template ─────────────────────────────────
function buildCrimeInfoWindow(crime) {
  const colors = severityColors(crime.severity);
  return `
    <div style="
      background: #162d62;
      border-radius: 16px;
      padding: 16px;
      min-width: 240px;
      max-width: 300px;
      font-family: 'DM Sans', sans-serif;
      color: #E8F4FD;
    ">
      <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:${colors.text};text-transform:uppercase;margin-bottom:6px;">
        ${crime.type}
      </div>
      <div style="font-size:14px;font-weight:600;margin-bottom:8px;line-height:1.4;">
        ${crime.description.slice(0, 80)}${crime.description.length > 80 ? '…' : ''}
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;">
        <span style="
          padding:3px 8px;border-radius:6px;font-size:10px;font-weight:700;
          background:${crime.status === 'Verified' ? 'rgba(0,245,160,0.12)' : 'rgba(255,154,0,0.12)'};
          color:${crime.status === 'Verified' ? '#00F5A0' : '#FF9A00'};
          border:1px solid ${crime.status === 'Verified' ? 'rgba(0,245,160,0.3)' : 'rgba(255,154,0,0.3)'};
        ">${crime.status}</span>
        <span style="
          padding:3px 8px;border-radius:6px;font-size:10px;font-weight:600;
          background:rgba(155,184,212,0.08);color:#9BB8D4;
          border:1px solid rgba(155,184,212,0.18);
        ">${crime.date}</span>
        <span style="
          padding:3px 8px;border-radius:6px;font-size:10px;font-weight:600;
          background:${colors.bg};color:${colors.text};
          border:1px solid ${colors.border};
        ">${crime.area}</span>
      </div>
      <button onclick="window._safegridReport()" style="
        width:100%;padding:9px;border-radius:8px;
        background:linear-gradient(135deg,#c0392b,#FF3B3B);
        border:none;color:white;font-family:'DM Sans',sans-serif;
        font-weight:700;font-size:12px;cursor:pointer;
      ">🚨 Report Similar Incident</button>
    </div>
  `;
}

function buildSponsorInfoWindow(sponsor) {
  return `
    <div style="
      background: #162d62;
      border-radius: 16px;
      padding: 16px;
      min-width: 240px;
      max-width: 300px;
      font-family: 'DM Sans', sans-serif;
      color: #E8F4FD;
    ">
      <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#00AEEF;text-transform:uppercase;margin-bottom:4px;">
        ★ ${sponsor.badge}
      </div>
      <div style="font-size:15px;font-weight:700;margin-bottom:3px;">${sponsor.name}</div>
      <div style="font-size:12px;color:#9BB8D4;margin-bottom:8px;">${sponsor.type}</div>
      <div style="font-size:12px;color:#9BB8D4;line-height:1.5;margin-bottom:10px;">${sponsor.description}</div>
      <div style="display:flex;gap:6px;margin-bottom:10px;">
        <span style="
          padding:3px 8px;border-radius:6px;font-size:10px;font-weight:700;
          background:rgba(0,174,239,0.12);color:#00AEEF;
          border:1px solid rgba(0,174,239,0.3);
        ">Sponsored</span>
        <span style="
          padding:3px 8px;border-radius:6px;font-size:10px;font-weight:600;
          background:rgba(155,184,212,0.08);color:#9BB8D4;
          border:1px solid rgba(155,184,212,0.18);
        ">Response: ${sponsor.responseTime}</span>
      </div>
      <button onclick="window._safegridSponsorCTA('${sponsor.id}')" style="
        width:100%;padding:9px;border-radius:8px;
        background:linear-gradient(135deg,#0090cc,#00AEEF);
        border:none;color:white;font-family:'DM Sans',sans-serif;
        font-weight:700;font-size:12px;cursor:pointer;
      ">${sponsor.cta}</button>
    </div>
  `;
}

// ── Component ─────────────────────────────────────────────────
function MapComponent({ crimes = [], sponsored = [], userPosition, onReportClick, onSponsorCTA }) {
  const mapRef        = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef    = useRef([]);
  const infoWindowRef = useRef(null);
  const { google, loaded, error } = useGoogleMaps();

  // Expose callbacks to info window buttons
  useEffect(() => {
    window._safegridReport      = () => onReportClick?.();
    window._safegridSponsorCTA  = (id) => onSponsorCTA?.(id);
    return () => {
      delete window._safegridReport;
      delete window._safegridSponsorCTA;
    };
  }, [onReportClick, onSponsorCTA]);

  // ── Initialize Map ─────────────────────────────────────────
  useEffect(() => {
    if (!loaded || !google || !mapRef.current) return;

    const map = new google.maps.Map(mapRef.current, {
      center:            NAIROBI_CENTER,
      zoom:              NAIROBI_ZOOM,
      styles:            DARK_MAP_STYLE,
      disableDefaultUI:  true,
      zoomControl:       false, // We use custom controls
      mapTypeControl:    false,
      streetViewControl: false,
      fullscreenControl: false,
      clickableIcons:    false,
      backgroundColor:   '#0A1F44',
    });

    mapInstanceRef.current = map;

    // Close info window on map click
    map.addListener('click', () => {
      infoWindowRef.current?.close();
    });
  }, [loaded, google]);

  // ── Add / Update Crime Markers ────────────────────────────
  useEffect(() => {
    if (!mapInstanceRef.current || !google) return;

    // Clear old markers
    markersRef.current.forEach((m) => m.setMap(null));
    markersRef.current = [];

    const iw = new google.maps.InfoWindow({ maxWidth: 320 });
    infoWindowRef.current = iw;

    // Crime markers
    crimes.forEach((crime) => {
      const colors = severityColors(crime.severity);
      // INSERT IMAGE/ICON URL HERE — use createMarkerIcon() or a CDN URL
      const icon = {
        url:        createMarkerIcon(colors.text),
        scaledSize: new google.maps.Size(36, 44),
        anchor:     new google.maps.Point(18, 44),
      };

      const marker = new google.maps.Marker({
        position:  { lat: crime.lat, lng: crime.lng },
        map:       mapInstanceRef.current,
        icon,
        title:     crime.type,
        animation: google.maps.Animation.DROP,
      });

      marker.addListener('click', () => {
        iw.setContent(buildCrimeInfoWindow(crime));
        iw.open(mapInstanceRef.current, marker);
      });

      markersRef.current.push(marker);
    });

    // Sponsored markers
    sponsored.forEach((sponsor) => {
      // INSERT IMAGE/ICON URL HERE — sponsored marker uses blue
      const icon = {
        url:        createMarkerIcon('#00AEEF', '★'),
        scaledSize: new google.maps.Size(36, 44),
        anchor:     new google.maps.Point(18, 44),
      };

      const marker = new google.maps.Marker({
        position:  { lat: sponsor.lat, lng: sponsor.lng },
        map:       mapInstanceRef.current,
        icon,
        title:     sponsor.name,
        zIndex:    5, // Render above crime markers
      });

      marker.addListener('click', () => {
        iw.setContent(buildSponsorInfoWindow(sponsor));
        iw.open(mapInstanceRef.current, marker);
      });

      markersRef.current.push(marker);
    });
  }, [crimes, sponsored, google]);

  // ── User Location Marker ───────────────────────────────────
  useEffect(() => {
    if (!mapInstanceRef.current || !google || !userPosition) return;

    // INSERT IMAGE/ICON URL HERE for user location icon
    const userIcon = {
      url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
          <circle cx="12" cy="12" r="8" fill="#00F5A0" opacity="0.9"/>
          <circle cx="12" cy="12" r="12" fill="#00F5A0" opacity="0.2"/>
          <circle cx="12" cy="12" r="4" fill="white"/>
        </svg>
      `)}`,
      scaledSize: new google.maps.Size(24, 24),
      anchor:     new google.maps.Point(12, 12),
    };

    const userMarker = new google.maps.Marker({
      position:  userPosition,
      map:       mapInstanceRef.current,
      icon:      userIcon,
      title:     'Your Location',
      zIndex:    10,
    });

    // Pan to user
    mapInstanceRef.current.panTo(userPosition);

    return () => userMarker.setMap(null);
  }, [userPosition, google]);

  // ── Zoom controls (exposed via ref) ──────────────────────
  const zoomIn  = useCallback(() => mapInstanceRef.current?.setZoom((mapInstanceRef.current.getZoom() ?? NAIROBI_ZOOM) + 1), []);
  const zoomOut = useCallback(() => mapInstanceRef.current?.setZoom((mapInstanceRef.current.getZoom() ?? NAIROBI_ZOOM) - 1), []);
  const panTo   = useCallback((pos) => mapInstanceRef.current?.panTo(pos), []);

  // Expose controls on the window for sibling components
  useEffect(() => {
    window._safegridMapControls = { zoomIn, zoomOut, panTo };
    return () => { delete window._safegridMapControls; };
  }, [zoomIn, zoomOut, panTo]);

  // ── Render ────────────────────────────────────────────────
  if (error) {
    return (
      <div className="w-full h-full flex items-center justify-center" style={{ background: 'var(--primary)' }}>
        <div style={{
          background: 'var(--surface)',
          border: '1px solid rgba(255,59,59,0.3)',
          borderRadius: 'var(--radius-lg)',
          padding: '24px',
          maxWidth: '320px',
          textAlign: 'center',
        }}>
          <div style={{ fontSize: '32px', marginBottom: '12px' }}>🗺️</div>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: '8px' }}>
            Map Unavailable
          </div>
          <div style={{ fontSize: '13px', color: 'var(--text-2)', lineHeight: 1.5 }}>{error}</div>
          <div style={{ fontSize: '11px', color: 'var(--text-3)', marginTop: '12px' }}>
            {/* INSERT GOOGLE MAPS API KEY HERE in src/hooks/useGoogleMaps.js */}
            Check that your Google Maps API key is configured.
          </div>
        </div>
      </div>
    );
  }

  if (!loaded) {
    return (
      <div className="w-full h-full flex items-center justify-center" style={{ background: 'var(--primary)' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: '40px', height: '40px', borderRadius: '50%',
            border: '3px solid rgba(0,174,239,0.3)',
            borderTopColor: 'var(--secondary)',
            animation: 'spin 0.8s linear infinite',
            margin: '0 auto 12px',
          }} />
          <div style={{ fontSize: '13px', color: 'var(--text-3)' }}>Loading SafeGrid Map…</div>
        </div>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return <div ref={mapRef} id="map-root" style={{ width: '100%', height: '100%' }} />;
}

export default MapComponent;
