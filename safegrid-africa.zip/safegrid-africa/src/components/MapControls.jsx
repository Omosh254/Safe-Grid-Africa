/* ============================================================
   SafeGrid Africa — MapControls
   Floating map control buttons: zoom, geolocation, layers.
   ============================================================ */

import React, { useState } from 'react';

const btn = {
  width: '40px',
  height: '40px',
  borderRadius: '10px',
  background: 'rgba(15,38,84,0.92)',
  backdropFilter: 'blur(10px)',
  WebkitBackdropFilter: 'blur(10px)',
  border: '1px solid rgba(0,174,239,0.32)',
  color: 'var(--text)',
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '18px',
  fontWeight: 700,
  transition: 'all 0.2s',
  fontFamily: 'var(--font-body)',
  flexShrink: 0,
};

function MapBtn({ icon, label, onClick, active, danger }) {
  const [hovered, setHovered] = useState(false);

  return (
    <button
      style={{
        ...btn,
        background: active
          ? 'rgba(0,174,239,0.25)'
          : danger
          ? 'rgba(255,59,59,0.15)'
          : hovered
          ? 'rgba(0,174,239,0.15)'
          : 'rgba(15,38,84,0.92)',
        borderColor: active
          ? 'rgba(0,174,239,0.7)'
          : danger
          ? 'rgba(255,59,59,0.4)'
          : hovered
          ? 'rgba(0,174,239,0.5)'
          : 'rgba(0,174,239,0.32)',
        color: active ? 'var(--secondary)' : danger ? 'var(--danger-soft)' : 'var(--text)',
      }}
      title={label}
      aria-label={label}
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {icon}
    </button>
  );
}

function Divider() {
  return (
    <div style={{
      width: '28px', height: '1px',
      background: 'rgba(0,174,239,0.2)',
      margin: '2px auto',
    }} />
  );
}

function MapControls({ onZoomIn, onZoomOut, onLocate, onTogglePanel, panelOpen, locating }) {
  const [showLayers, setShowLayers] = useState(false);

  function handleZoomIn() {
    // Uses the exposed map controls from MapComponent
    window._safegridMapControls?.zoomIn();
    onZoomIn?.();
  }

  function handleZoomOut() {
    window._safegridMapControls?.zoomOut();
    onZoomOut?.();
  }

  function handleLocate() {
    onLocate?.();
  }

  return (
    <div style={{
      position: 'absolute',
      right: '12px',
      top: '50%',
      transform: 'translateY(-50%)',
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      zIndex: 20,
    }}>
      {/* Zoom */}
      <MapBtn icon="+" label="Zoom in"  onClick={handleZoomIn} />
      <MapBtn icon="−" label="Zoom out" onClick={handleZoomOut} />

      <Divider />

      {/* Geolocate */}
      <MapBtn
        icon={locating ? '⟳' : '◎'}
        label="My location"
        onClick={handleLocate}
        active={locating}
      />

      {/* Toggle panel */}
      <MapBtn
        icon="⊞"
        label={panelOpen ? 'Hide panel' : 'Show panel'}
        onClick={onTogglePanel}
        active={panelOpen}
      />

      <Divider />

      {/* Layers toggle */}
      <MapBtn
        icon="☰"
        label="Map layers"
        onClick={() => setShowLayers((v) => !v)}
        active={showLayers}
      />

      {/* Layer picker dropdown */}
      {showLayers && (
        <div style={{
          position: 'absolute',
          right: '48px',
          top: '50%',
          transform: 'translateY(-50%)',
          background: 'rgba(15,38,84,0.96)',
          backdropFilter: 'blur(16px)',
          border: '1px solid rgba(0,174,239,0.3)',
          borderRadius: '12px',
          padding: '12px',
          minWidth: '160px',
          zIndex: 30,
          animation: 'popIn 0.2s cubic-bezier(0.34,1.56,0.64,1)',
        }}>
          <div style={{ fontSize: '10px', fontWeight: 700, color: 'var(--text-3)', letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: '8px' }}>
            Map Layers
          </div>
          {[
            { id: 'crimes',    label: 'Crime Markers',     icon: '🔴', defaultOn: true  },
            { id: 'sponsors',  label: 'Partner Markers',   icon: '🔵', defaultOn: true  },
            { id: 'heatmap',   label: 'Danger Heat Map',   icon: '🌡️', defaultOn: false },
            { id: 'zones',     label: 'Safe Zone Overlay', icon: '🟢', defaultOn: false },
          ].map((layer) => (
            <label
              key={layer.id}
              style={{
                display: 'flex', alignItems: 'center', gap: '8px',
                padding: '6px 0', cursor: 'pointer',
                borderBottom: '1px solid rgba(255,255,255,0.05)',
              }}
            >
              <input
                type="checkbox"
                defaultChecked={layer.defaultOn}
                style={{ accentColor: 'var(--secondary)', width: '14px', height: '14px' }}
                // INSERT BACKEND API ENDPOINT HERE — persist layer preferences
              />
              <span style={{ fontSize: '12px' }}>{layer.icon}</span>
              <span style={{ fontSize: '12px', color: 'var(--text-2)' }}>{layer.label}</span>
            </label>
          ))}
        </div>
      )}
    </div>
  );
}

export default MapControls;
