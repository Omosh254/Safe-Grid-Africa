/* ============================================================
   SafeGrid Africa — BottomNav
   Mobile-only bottom navigation with active state & badge.
   ============================================================ */

import React from 'react';

const NAV_ITEMS = [
  { id: 'map',       icon: '🗺',  label: 'Map'      },
  { id: 'alerts',    icon: '🔔',  label: 'Alerts'   },
  { id: 'report',    icon: '🚨',  label: 'Report',  accent: true },
  { id: 'filters',   icon: '⚙',   label: 'Filter'   },
  { id: 'sponsored', icon: '★',   label: 'Partners' },
];

function BottomNav({ activeView, onNavigate, alertCount = 0 }) {
  return (
    <nav
      style={{
        height: '64px',
        background: 'rgba(15,38,84,0.96)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        borderTop: '1px solid rgba(0,174,239,0.18)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-around',
        padding: '0 4px',
        flexShrink: 0,
        zIndex: 100,
        // Safe area for notched phones
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
      aria-label="Main navigation"
    >
      {NAV_ITEMS.map((item) => {
        const isActive = activeView === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            aria-label={item.label}
            aria-current={isActive ? 'page' : undefined}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '3px',
              padding: item.accent ? '0' : '8px 10px',
              borderRadius: item.accent ? '50%' : '10px',
              cursor: 'pointer',
              border: 'none',
              background: item.accent
                ? 'linear-gradient(135deg, var(--danger-dark), var(--danger))'
                : isActive
                ? 'rgba(0,174,239,0.12)'
                : 'none',
              color: item.accent ? 'white' : isActive ? 'var(--secondary)' : 'var(--text-3)',
              fontFamily: 'var(--font-body)',
              transition: 'all 0.2s',
              position: 'relative',
              ...(item.accent
                ? {
                    width: '48px',
                    height: '48px',
                    boxShadow: '0 4px 16px rgba(255,59,59,0.4)',
                    marginBottom: '8px',
                  }
                : {}),
            }}
          >
            {/* Alert badge on bell */}
            {item.id === 'alerts' && alertCount > 0 && (
              <div style={{
                position: 'absolute',
                top: '4px', right: '4px',
                width: '14px', height: '14px',
                borderRadius: '50%',
                background: 'var(--danger)',
                border: '1.5px solid var(--surface)',
                color: 'white',
                fontSize: '8px',
                fontWeight: 800,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {alertCount > 9 ? '9+' : alertCount}
              </div>
            )}

            <span style={{ fontSize: item.accent ? '20px' : '18px', lineHeight: 1 }}>{item.icon}</span>

            {!item.accent && (
              <span style={{ fontSize: '9px', fontWeight: 700, letterSpacing: '0.3px' }}>
                {item.label}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );
}

export default BottomNav;
