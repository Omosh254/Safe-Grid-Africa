/* ============================================================
   SafeGrid Africa — LoadingScreen
   Animated splash screen shown during initial app load.
   ============================================================ */

import React, { useEffect, useState } from 'react';

const STEPS = [
  'Connecting to SafeGrid network…',
  'Loading crime incident data…',
  'Initialising map layers…',
  'Fetching safety alerts…',
  'Ready.',
];

function LoadingScreen({ onComplete }) {
  const [stepIndex, setStepIndex] = useState(0);
  const [progress,  setProgress ] = useState(0);
  const [done,      setDone     ] = useState(false);

  useEffect(() => {
    let step = 0;
    const interval = setInterval(() => {
      step++;
      setStepIndex(step);
      setProgress(Math.round((step / STEPS.length) * 100));

      if (step >= STEPS.length - 1) {
        clearInterval(interval);
        setTimeout(() => {
          setDone(true);
          setTimeout(onComplete, 350);
        }, 400);
      }
    }, 420);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      background: 'var(--primary)',
      zIndex: 999,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '24px',
      opacity: done ? 0 : 1,
      transition: 'opacity 0.35s ease-out',
    }}>
      {/* Animated grid logo */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr 1fr',
        gap: '5px',
        marginBottom: '28px',
        animation: 'popIn 0.4s cubic-bezier(0.34,1.56,0.64,1)',
      }}>
        {[...Array(9)].map((_, i) => (
          <div
            key={i}
            style={{
              width: '20px',
              height: '20px',
              borderRadius: '5px',
              background: i % 2 === 0 ? 'var(--secondary)' : 'var(--accent)',
              opacity: 0.3 + (i / 9) * 0.7,
              animation: `pulseRing ${1 + i * 0.15}s ease-in-out infinite alternate`,
            }}
          />
        ))}
      </div>

      {/* Brand */}
      <div style={{
        fontFamily: 'var(--font-display)',
        fontSize: '28px',
        fontWeight: 800,
        marginBottom: '4px',
        letterSpacing: '-0.5px',
      }}>
        <span style={{ color: 'var(--secondary)' }}>Safe</span>Grid
        <span style={{ color: 'var(--accent)', marginLeft: '6px', fontSize: '16px', fontWeight: 600 }}>Africa</span>
      </div>
      <div style={{ fontSize: '12px', color: 'var(--text-3)', marginBottom: '40px', letterSpacing: '1px', textTransform: 'uppercase' }}>
        Public Safety Network
      </div>

      {/* Progress bar */}
      <div style={{ width: '100%', maxWidth: '240px', marginBottom: '14px' }}>
        <div style={{
          height: '3px',
          borderRadius: '2px',
          background: 'rgba(255,255,255,0.08)',
          overflow: 'hidden',
        }}>
          <div style={{
            height: '100%',
            borderRadius: '2px',
            background: `linear-gradient(90deg, var(--secondary), var(--accent))`,
            width: `${progress}%`,
            transition: 'width 0.4s cubic-bezier(0.4,0,0.2,1)',
          }} />
        </div>
      </div>

      {/* Status text */}
      <div style={{
        fontSize: '12px',
        color: 'var(--text-3)',
        height: '18px',
        transition: 'opacity 0.3s',
        textAlign: 'center',
      }}>
        {STEPS[Math.min(stepIndex, STEPS.length - 1)]}
      </div>

      {/* Version */}
      <div style={{
        position: 'absolute',
        bottom: '20px',
        fontSize: '10px',
        color: 'rgba(155,184,212,0.3)',
      }}>
        SafeGrid Africa v1.0.0
      </div>
    </div>
  );
}

export default LoadingScreen;
