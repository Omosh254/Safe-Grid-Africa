/* ============================================================
   SafeGrid Africa — Header
   App header with logo, safety badge, and alert bell.
   ============================================================ */

import React, { useState } from 'react';
import { getSafetyScore } from '../utils/helpers';
import { MOCK_ALERTS } from '../data/mockData';

// Logo grid icon
function LogoIcon() {
  return (
    <div style={{
      width: '32px', height: '32px',
      background: 'linear-gradient(135deg, #00AEEF, #00F5A0)',
      borderRadius: '9px',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
    }}>
      {/* INSERT IMAGE/ICON URL HERE for brand logo */}
      <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="1" y="1" width="5" height="5" rx="1.5" fill="#0A1F44" opacity="0.9"/>
        <rect x="7" y="1" width="5" height="5" rx="1.5" fill="#0A1F44" opacity="0.7"/>
        <rect x="13" y="1" width="4" height="5" rx="1.5" fill="#0A1F44" opacity="0.9"/>
        <rect x="1" y="7" width="5" height="4" rx="1.5" fill="#0A1F44" opacity="0.5"/>
        <rect x="7" y="7" width="5" height="4" rx="1.5" fill="#0A1F44" opacity="0.9"/>
        <rect x="13" y="7" width="4" height="4" rx="1.5" fill="#0A1F44" opacity="0.6"/>
        <rect x="1" y="12" width="5" height="5" rx="1.5" fill="#0A1F44" opacity="0.9"/>
        <rect x="7" y="12" width="5" height="4" rx="1.5" fill="#0A1F44" opacity="0.6"/>
        <rect x="13" y="12" width="4" height="5" rx="1.5" fill="#0A1F44" opacity="0.8"/>
      </svg>
    </div>
  );
}

function Header({ onAlertsClick, onProfileClick }) {
  const highAlerts    = MOCK_ALERTS.filter((a) => a.level === 'high').length;
  const { score, color } = getSafetyScore('Westlands');
  const [profileOpen, setProfileOpen] = useState(false);

  return (
    <header style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 14px',
      height: '52px',
      background: 'rgba(15,38,84,0.94)',
      borderBottom: '1px solid rgba(0,174,239,0.18)',
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      zIndex: 100,
      flexShrink: 0,
      position: 'relative',
    }}>

      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <LogoIcon />
        <div>
          <div style={{
            fontFamily: 'var(--font-display)',
            fontWeight: 800,
            fontSize: '16px',
            letterSpacing: '-0.3px',
            lineHeight: 1.1,
          }}>
            <span style={{ color: 'var(--secondary)' }}>Safe</span>Grid
            <span style={{ fontSize: '11px', fontWeight: 400, color: 'var(--text-3)', marginLeft: '4px' }}>Africa</span>
          </div>
          <div style={{ fontSize: '9px', color: 'var(--text-3)', letterSpacing: '0.5px', textTransform: 'uppercase' }}>
            Nairobi Safety Network
          </div>
        </div>
      </div>

      {/* Right actions */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>

        {/* Safety score badge */}
        <div style={{
          padding: '4px 10px',
          borderRadius: '20px',
          fontSize: '11px',
          fontWeight: 700,
          background: `${color}18`,
          color,
          border: `1px solid ${color}40`,
          letterSpacing: '0.3px',
          display: 'flex',
          alignItems: 'center',
          gap: '4px',
        }}>
          <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: color }} />
          {score.toFixed(1)}
        </div>

        {/* Alert bell */}
        <button
          style={{
            position: 'relative',
            width: '36px', height: '36px',
            borderRadius: '10px',
            background: highAlerts > 0 ? 'rgba(255,59,59,0.14)' : 'rgba(255,255,255,0.06)',
            border: `1px solid ${highAlerts > 0 ? 'rgba(255,59,59,0.35)' : 'rgba(255,255,255,0.12)'}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', fontSize: '16px',
            transition: 'all 0.2s',
          }}
          onClick={onAlertsClick}
          aria-label={`${highAlerts} high-priority alerts`}
          title="View alerts"
        >
          🔔
          {highAlerts > 0 && (
            <div style={{
              position: 'absolute', top: '5px', right: '5px',
              width: '9px', height: '9px',
              borderRadius: '50%',
              background: 'var(--danger)',
              border: '1.5px solid var(--surface)',
              animation: 'pulseRing 2s infinite',
            }} />
          )}
        </button>

        {/* Profile / Auth */}
        <button
          style={{
            width: '36px', height: '36px',
            borderRadius: '50%',
            background: 'rgba(0,174,239,0.15)',
            border: '1px solid rgba(0,174,239,0.3)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', fontSize: '14px',
            fontFamily: 'var(--font-display)',
            fontWeight: 700,
            color: 'var(--secondary)',
            transition: 'all 0.2s',
            position: 'relative',
          }}
          onClick={() => { setProfileOpen((v) => !v); onProfileClick?.(); }}
          aria-label="User profile"
          title="Profile"
        >
          {/* INSERT AUTH LOGIC HERE — show user initials or avatar */}
          {/* INSERT IMAGE/ICON URL HERE for user avatar */}
          SG
        </button>

        {/* Profile dropdown */}
        {profileOpen && (
          <div style={{
            position: 'absolute',
            top: '52px', right: '12px',
            background: 'rgba(15,38,84,0.98)',
            backdropFilter: 'blur(16px)',
            border: '1px solid rgba(0,174,239,0.25)',
            borderRadius: '14px',
            padding: '12px',
            minWidth: '200px',
            zIndex: 200,
            animation: 'slideUp 0.25s cubic-bezier(0.34,1.56,0.64,1)',
            boxShadow: '0 12px 40px rgba(0,0,0,0.5)',
          }}>
            {/* INSERT AUTH LOGIC HERE — user info from auth token */}
            <div style={{ padding: '8px 0 12px', borderBottom: '1px solid rgba(255,255,255,0.08)', marginBottom: '8px' }}>
              <div style={{ fontSize: '14px', fontWeight: 700 }}>Guest User</div>
              <div style={{ fontSize: '11px', color: 'var(--text-3)' }}>
                {/* INSERT AUTH LOGIC HERE */}
                Sign in for full access
              </div>
            </div>
            {[
              { icon: '🔐', label: 'Sign In / Register' },
              { icon: '📋', label: 'My Reports'         },
              { icon: '🔔', label: 'Notification Settings' },
              { icon: '❓', label: 'Help & Support'     },
            ].map(({ icon, label }) => (
              <button
                key={label}
                style={{
                  display: 'flex', alignItems: 'center', gap: '10px',
                  width: '100%', padding: '8px 4px',
                  background: 'none', border: 'none',
                  color: 'var(--text-2)', cursor: 'pointer',
                  fontSize: '13px', fontFamily: 'var(--font-body)',
                  borderRadius: '6px', transition: 'background 0.2s',
                  textAlign: 'left',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(255,255,255,0.06)')}
                onMouseLeave={(e) => (e.currentTarget.style.background = 'none')}
                // INSERT AUTH LOGIC HERE for each menu action
              >
                <span style={{ fontSize: '14px' }}>{icon}</span>
                {label}
              </button>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}

export default Header;
