/* ============================================================
   SafeGrid Africa — SponsoredPanel
   Displays sponsored/verified partner listings.
   INSERT BACKEND API ENDPOINT HERE for live sponsor data.
   INSERT IMAGE/ICON URL HERE for sponsor logos.
   ============================================================ */

import React from 'react';
import { MOCK_SPONSORED } from '../data/mockData';
import { logSponsorClick } from '../utils/api';

function SponsorCard({ sponsor }) {
  async function handleCTA() {
    // INSERT BACKEND API ENDPOINT HERE — log click analytics
    try {
      await logSponsorClick(sponsor.id, 'cta_button');
    } catch {
      // Fail silently — analytics should never block UX
    }
    // INSERT SPONSOR URL HERE — open sponsor's website or deep link
    if (sponsor.website) {
      window.open(sponsor.website, '_blank', 'noopener,noreferrer');
    }
  }

  return (
    <div style={{
      padding: '14px',
      borderRadius: '12px',
      marginBottom: '10px',
      background: 'rgba(0,174,239,0.05)',
      border: '1px solid rgba(0,174,239,0.18)',
      transition: 'all 0.2s',
    }}
      onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(0,174,239,0.1)')}
      onMouseLeave={(e) => (e.currentTarget.style.background = 'rgba(0,174,239,0.05)')}
    >
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '8px' }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: '9px', fontWeight: 700, letterSpacing: '1px', color: 'var(--secondary)', textTransform: 'uppercase', marginBottom: '3px' }}>
            ★ {sponsor.badge}
          </div>
          <div style={{ fontSize: '14px', fontWeight: 700, marginBottom: '2px' }}>
            {sponsor.name}
          </div>
          <div style={{ fontSize: '11px', color: 'var(--text-3)' }}>
            {sponsor.type}
          </div>
        </div>
        {/* INSERT IMAGE/ICON URL HERE — sponsor logo */}
        <div style={{
          width: '40px', height: '40px', borderRadius: '10px',
          background: 'rgba(0,174,239,0.15)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '18px', flexShrink: 0, marginLeft: '10px',
        }}>
          🛡️
        </div>
      </div>

      {/* Description */}
      <div style={{ fontSize: '12px', color: 'var(--text-2)', lineHeight: 1.5, marginBottom: '10px' }}>
        {sponsor.description}
      </div>

      {/* Meta row */}
      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '10px' }}>
        <span style={{
          padding: '3px 8px', borderRadius: '6px', fontSize: '10px', fontWeight: 700,
          background: 'rgba(0,174,239,0.12)', color: 'var(--secondary)',
          border: '1px solid rgba(0,174,239,0.3)',
        }}>Sponsored</span>
        <span style={{
          padding: '3px 8px', borderRadius: '6px', fontSize: '10px', fontWeight: 600,
          background: 'rgba(155,184,212,0.08)', color: 'var(--text-2)',
          border: '1px solid rgba(155,184,212,0.18)',
        }}>📍 {sponsor.area}</span>
        <span style={{
          padding: '3px 8px', borderRadius: '6px', fontSize: '10px', fontWeight: 600,
          background: 'rgba(0,245,160,0.08)', color: 'var(--accent)',
          border: '1px solid rgba(0,245,160,0.2)',
        }}>⚡ {sponsor.responseTime}</span>
      </div>

      {/* CTA */}
      <button
        onClick={handleCTA}
        style={{
          width: '100%', padding: '9px', borderRadius: '8px',
          background: 'rgba(0,174,239,0.15)',
          border: '1px solid rgba(0,174,239,0.35)',
          color: 'var(--secondary)',
          fontFamily: 'var(--font-body)', fontWeight: 700, fontSize: '12px',
          cursor: 'pointer', transition: 'all 0.2s',
        }}
        onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(0,174,239,0.28)')}
        onMouseLeave={(e) => (e.currentTarget.style.background = 'rgba(0,174,239,0.15)')}
      >
        {sponsor.cta} →
      </button>
    </div>
  );
}

function SponsoredPanel() {
  return (
    <div>
      <div style={{
        fontSize: '12px', color: 'var(--text-3)', lineHeight: 1.5,
        marginBottom: '14px', padding: '10px 12px',
        background: 'rgba(255,255,255,0.03)',
        border: '1px solid var(--border)',
        borderRadius: '8px',
      }}>
        Verified businesses in your area providing security, transport, and safety services.
        {/* INSERT BACKEND API ENDPOINT HERE — load live sponsor data */}
      </div>

      {MOCK_SPONSORED.map((s) => (
        <SponsorCard key={s.id} sponsor={s} />
      ))}

      {/* Become a partner CTA */}
      <div style={{
        padding: '14px', borderRadius: '12px', textAlign: 'center',
        background: 'rgba(0,174,239,0.04)',
        border: '1px dashed rgba(0,174,239,0.25)',
        marginTop: '4px',
      }}>
        <div style={{ fontSize: '13px', fontWeight: 600, marginBottom: '4px' }}>
          Are you a safety business?
        </div>
        <div style={{ fontSize: '11px', color: 'var(--text-3)', marginBottom: '10px' }}>
          Reach thousands of safety-conscious users in Nairobi.
        </div>
        <button
          style={{
            padding: '8px 20px', borderRadius: '8px',
            background: 'rgba(0,174,239,0.12)',
            border: '1px solid rgba(0,174,239,0.3)',
            color: 'var(--secondary)',
            fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: '12px',
            cursor: 'pointer',
          }}
          // INSERT BACKEND API ENDPOINT HERE — partner sign-up flow
          onClick={() => console.log('// INSERT PARTNER SIGN-UP URL HERE')}
        >
          Become a Partner
        </button>
      </div>
    </div>
  );
}

export default SponsoredPanel;
