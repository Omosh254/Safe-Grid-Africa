/* ============================================================
   SafeGrid Africa — FiltersPanel
   Crime type, time range, status, and severity filters.
   ============================================================ */

import React from 'react';
import { CRIME_TYPES, TIME_RANGES } from '../data/mockData';

function ChipButton({ label, active, onClick, color }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: '6px 12px',
        borderRadius: '20px',
        fontSize: '12px',
        fontWeight: 500,
        cursor: 'pointer',
        border: `1px solid ${active ? (color || 'var(--secondary)') : 'var(--border)'}`,
        background: active ? `${color || 'var(--secondary)'}20` : 'transparent',
        color: active ? (color || 'var(--secondary)') : 'var(--text-2)',
        transition: 'all 0.18s',
        fontFamily: 'var(--font-body)',
      }}
      onMouseEnter={(e) => {
        if (!active) {
          e.currentTarget.style.background = 'rgba(255,255,255,0.07)';
          e.currentTarget.style.color = 'var(--text)';
        }
      }}
      onMouseLeave={(e) => {
        if (!active) {
          e.currentTarget.style.background = 'transparent';
          e.currentTarget.style.color = 'var(--text-2)';
        }
      }}
    >
      {label}
    </button>
  );
}

function FilterSection({ title, children }) {
  return (
    <div style={{ marginBottom: '20px' }}>
      <div style={{
        fontSize: '11px', fontWeight: 700, letterSpacing: '0.5px',
        color: 'var(--text-3)', textTransform: 'uppercase', marginBottom: '10px',
      }}>
        {title}
      </div>
      {children}
    </div>
  );
}

function FiltersPanel({ filters, toggleType, setTimeRange, setStatus, setSeverity, resetFilters, activeFilterCount }) {
  const STATUSES  = ['All', 'Verified', 'Unverified'];
  const SEVERITIES = ['All', 'High', 'Medium', 'Low'];

  const severityColors = { High: '#FF3B3B', Medium: '#FF9A00', Low: '#FFD93D' };

  return (
    <div>
      {/* Active filter count + reset */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <div style={{ fontSize: '13px', color: 'var(--text-2)' }}>
          {activeFilterCount > 0
            ? `${activeFilterCount} filter${activeFilterCount > 1 ? 's' : ''} active`
            : 'No filters active'}
        </div>
        {activeFilterCount > 0 && (
          <button
            onClick={resetFilters}
            style={{
              fontSize: '11px', fontWeight: 600, color: 'var(--secondary)',
              background: 'none', border: 'none', cursor: 'pointer',
              textDecoration: 'underline',
            }}
          >
            Reset all
          </button>
        )}
      </div>

      {/* Crime Type */}
      <FilterSection title="Crime Type">
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          {CRIME_TYPES.map((t) => (
            <ChipButton
              key={t}
              label={t}
              active={filters.types.includes(t) || (t === 'All' && filters.types.includes('All'))}
              onClick={() => toggleType(t)}
            />
          ))}
        </div>
      </FilterSection>

      {/* Time Range */}
      <FilterSection title="Time Range">
        <select
          className="sg-select"
          value={filters.timeRange}
          onChange={(e) => setTimeRange(e.target.value)}
        >
          {TIME_RANGES.map((r) => (
            <option key={r.value} value={r.value}>{r.label}</option>
          ))}
        </select>
      </FilterSection>

      {/* Status */}
      <FilterSection title="Status">
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          {STATUSES.map((s) => {
            const color = s === 'Verified' ? '#00F5A0' : s === 'Unverified' ? '#FF9A00' : undefined;
            return (
              <ChipButton
                key={s}
                label={s}
                active={filters.status === s}
                onClick={() => setStatus(s)}
                color={color}
              />
            );
          })}
        </div>
      </FilterSection>

      {/* Severity */}
      <FilterSection title="Severity">
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          {SEVERITIES.map((s) => (
            <ChipButton
              key={s}
              label={s}
              active={filters.severity === s}
              onClick={() => setSeverity(s)}
              color={s !== 'All' ? severityColors[s] : undefined}
            />
          ))}
        </div>
      </FilterSection>

      {/* Legend */}
      <div style={{
        background: 'rgba(255,255,255,0.03)',
        border: '1px solid var(--border)',
        borderRadius: '10px',
        padding: '12px',
      }}>
        <div style={{ fontSize: '11px', fontWeight: 700, color: 'var(--text-3)', letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: '10px' }}>
          Map Legend
        </div>
        {[
          { color: '#FF3B3B', label: 'Crime Marker — High Risk' },
          { color: '#FF9A00', label: 'Crime Marker — Medium Risk' },
          { color: '#FFD93D', label: 'Crime Marker — Low Risk' },
          { color: '#00AEEF', label: 'Sponsored Partner' },
          { color: '#00F5A0', label: 'Your Location' },
        ].map(({ color, label }) => (
          <div key={label} style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
            <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: color, flexShrink: 0 }} />
            <span style={{ fontSize: '12px', color: 'var(--text-2)' }}>{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default FiltersPanel;
