import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// ── PWA SERVICE WORKER REGISTRATION ──────────────────────────
// Registers the service worker for offline support and push notifications.
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/service-worker.js')
      .then((registration) => {
        console.log('[SafeGrid] Service Worker registered:', registration.scope);

        // Check for updates every 60 seconds
        setInterval(() => registration.update(), 60 * 1000);

        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          newWorker?.addEventListener('statechange', () => {
            if (
              newWorker.state === 'installed' &&
              navigator.serviceWorker.controller
            ) {
              // New version available — notify user
              console.log('[SafeGrid] New version available. Refresh to update.');
            }
          });
        });
      })
      .catch((error) => {
        console.error('[SafeGrid] Service Worker registration failed:', error);
      });
  });
}
