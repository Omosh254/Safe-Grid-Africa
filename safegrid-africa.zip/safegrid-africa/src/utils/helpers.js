/* ============================================================
   SafeGrid Africa — Helper Utilities
   ============================================================ */

import { AREA_SCORES } from '../data/mockData';

/**
 * Format a date string into a relative label (e.g., "2 hours ago").
 * @param {string} dateStr
 * @returns {string}
 */
export function timeAgo(dateStr) {
  const date = new Date(dateStr);
  const now  = new Date();
  const diff = Math.floor((now - date) / 1000); // seconds

  if (diff < 60)          return 'Just now';
  if (diff < 3600)        return `${Math.floor(diff / 60)} min ago`;
  if (diff < 86400)       return `${Math.floor(diff / 3600)} hours ago`;
  if (diff < 604800)      return `${Math.floor(diff / 86400)} days ago`;
  return date.toLocaleDateString('en-KE', { day: 'numeric', month: 'short', year: 'numeric' });
}

/**
 * Calculate the overall safety score for an area.
 * In production this would come from the backend.
 * @param {string} area
 * @returns {{ score: number, label: string, color: string }}
 */
export function getSafetyScore(area = 'Nairobi') {
  const config = AREA_SCORES[area] ?? { score: 7.8, trend: 'stable' };
  const { score } = config;

  let label, color;
  if (score >= 8)      { label = 'Very Safe';     color = '#00F5A0'; }
  else if (score >= 6.5) { label = 'Fairly Safe'; color = '#7ED56F'; }
  else if (score >= 5)  { label = 'Moderate Risk'; color = '#FF9A00'; }
  else                  { label = 'High Risk';     color = '#FF3B3B'; }

  return { score, label, color, trend: config.trend };
}

/**
 * Returns Tailwind/CSS color classes based on incident severity.
 */
export function severityColors(severity) {
  const map = {
    high:   { text: '#FF6B6B', bg: 'rgba(255,59,59,0.12)',  border: 'rgba(255,59,59,0.3)'  },
    medium: { text: '#FF9A00', bg: 'rgba(255,154,0,0.12)', border: 'rgba(255,154,0,0.3)' },
    low:    { text: '#FFD93D', bg: 'rgba(255,217,61,0.1)', border: 'rgba(255,217,61,0.25)' },
  };
  return map[severity] ?? map.low;
}

/**
 * Returns color for alert level.
 */
export function alertLevelColor(level) {
  const map = {
    high:   '#FF3B3B',
    medium: '#FF9A00',
    low:    '#00F5A0',
  };
  return map[level] ?? '#9BB8D4';
}

/**
 * Debounce a function call.
 */
export function debounce(fn, ms = 300) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}

/**
 * Clamp a number between min and max.
 */
export function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

/**
 * Format coordinates for display.
 */
export function formatCoords(lat, lng) {
  const latStr = `${Math.abs(lat).toFixed(4)}°${lat >= 0 ? 'N' : 'S'}`;
  const lngStr = `${Math.abs(lng).toFixed(4)}°${lng >= 0 ? 'E' : 'W'}`;
  return `${latStr}, ${lngStr}`;
}

/**
 * Create a custom Google Maps marker icon SVG data URL.
 * INSERT IMAGE/ICON URL HERE — or use this generated SVG.
 */
export function createMarkerIcon(color, label = '') {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 44" width="36" height="44">
      <path d="M18 0C8.059 0 0 8.059 0 18c0 13.5 18 26 18 26S36 31.5 36 18C36 8.059 27.941 0 18 0z"
            fill="${color}" />
      <circle cx="18" cy="18" r="8" fill="white" opacity="0.9"/>
      ${label ? `<text x="18" y="22" text-anchor="middle" font-size="9" font-weight="bold" fill="${color}">${label}</text>` : ''}
    </svg>
  `;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}
