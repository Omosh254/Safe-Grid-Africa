/* ============================================================
   SafeGrid Africa — API Utility
   All backend calls are centralised here.
   INSERT BACKEND API ENDPOINT HERE for each function.
   ============================================================ */

// ─────────────────────────────────────────────────────────────
// INSERT BACKEND API ENDPOINT HERE
// Example: 'https://api.safegridafrica.com/v1'
const API_BASE_URL = process.env.REACT_APP_API_URL || 'INSERT_YOUR_API_BASE_URL_HERE';
// ─────────────────────────────────────────────────────────────

// INSERT AUTH LOGIC HERE
// Example: import { getAuthToken } from './auth';
function getAuthHeaders() {
  // INSERT AUTH LOGIC HERE
  // const token = getAuthToken();
  // return token ? { Authorization: `Bearer ${token}` } : {};
  return {};
}

async function request(path, options = {}) {
  const url      = `${API_BASE_URL}${path}`;
  const headers  = {
    'Content-Type': 'application/json',
    ...getAuthHeaders(),
    ...(options.headers || {}),
  };

  const response = await fetch(url, { ...options, headers });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.message || `HTTP ${response.status}`);
  }

  return response.json();
}

// ── INCIDENTS ─────────────────────────────────────────────────

/**
 * Fetch all incidents with optional filters.
 * INSERT BACKEND API ENDPOINT HERE — GET /incidents
 */
export async function fetchIncidents(params = {}) {
  const query = new URLSearchParams(params).toString();
  // INSERT BACKEND API ENDPOINT HERE
  return request(`/incidents${query ? `?${query}` : ''}`);
}

/**
 * Submit a new incident report.
 * INSERT BACKEND API ENDPOINT HERE — POST /incidents
 *
 * @param {FormData|Object} reportData
 */
export async function submitIncident(reportData) {
  // INSERT BACKEND API ENDPOINT HERE
  // INSERT AUTH LOGIC HERE — require auth before submission
  return request('/incidents', {
    method: 'POST',
    body: JSON.stringify(reportData),
  });
}

/**
 * Upload evidence file (image/video) for an incident.
 * INSERT BACKEND API ENDPOINT HERE — POST /incidents/:id/media
 * INSERT IMAGE/ICON URL HERE for uploaded media
 *
 * @param {string} incidentId
 * @param {File} file
 */
export async function uploadEvidence(incidentId, file) {
  // INSERT BACKEND API ENDPOINT HERE
  const formData = new FormData();
  formData.append('file', file);
  formData.append('incidentId', incidentId);

  const response = await fetch(`${API_BASE_URL}/incidents/${incidentId}/media`, {
    method: 'POST',
    headers: getAuthHeaders(), // NOTE: do NOT set Content-Type; browser sets multipart boundary
    body: formData,
  });

  if (!response.ok) throw new Error(`Upload failed: HTTP ${response.status}`);
  return response.json();
}

// ── ALERTS ───────────────────────────────────────────────────

/**
 * Fetch safety alerts for a given area/radius.
 * INSERT BACKEND API ENDPOINT HERE — GET /alerts
 */
export async function fetchAlerts(lat, lng, radiusKm = 10) {
  // INSERT BACKEND API ENDPOINT HERE
  return request(`/alerts?lat=${lat}&lng=${lng}&radius=${radiusKm}`);
}

// ── SPONSORED LISTINGS ────────────────────────────────────────

/**
 * Fetch sponsored partners near a location.
 * INSERT BACKEND API ENDPOINT HERE — GET /sponsors
 */
export async function fetchSponsors(lat, lng) {
  // INSERT BACKEND API ENDPOINT HERE
  return request(`/sponsors?lat=${lat}&lng=${lng}`);
}

/**
 * Log a sponsor CTA click (for analytics).
 * INSERT BACKEND API ENDPOINT HERE — POST /sponsors/:id/click
 */
export async function logSponsorClick(sponsorId, ctaType) {
  // INSERT BACKEND API ENDPOINT HERE
  return request(`/sponsors/${sponsorId}/click`, {
    method: 'POST',
    body: JSON.stringify({ ctaType }),
  });
}

// ── GEOCODING ─────────────────────────────────────────────────

/**
 * Reverse geocode a coordinate to a human-readable address.
 * Uses Google Maps Geocoding API.
 * INSERT GOOGLE MAPS API KEY HERE in useGoogleMaps.js
 */
export async function reverseGeocode(lat, lng) {
  // INSERT GOOGLE MAPS API KEY HERE
  const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=INSERT_YOUR_GOOGLE_MAPS_API_KEY_HERE`;
  const res = await fetch(url);
  const data = await res.json();
  return data.results?.[0]?.formatted_address || `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
}

// ── AUTH ──────────────────────────────────────────────────────

/**
 * Register / login with phone number (OTP flow).
 * INSERT AUTH LOGIC HERE
 * INSERT BACKEND API ENDPOINT HERE — POST /auth/otp/request
 */
export async function requestOTP(phoneNumber) {
  // INSERT AUTH LOGIC HERE
  return request('/auth/otp/request', {
    method: 'POST',
    body: JSON.stringify({ phone: phoneNumber }),
  });
}

/**
 * Verify OTP and receive auth token.
 * INSERT AUTH LOGIC HERE
 * INSERT BACKEND API ENDPOINT HERE — POST /auth/otp/verify
 */
export async function verifyOTP(phoneNumber, code) {
  // INSERT AUTH LOGIC HERE
  return request('/auth/otp/verify', {
    method: 'POST',
    body: JSON.stringify({ phone: phoneNumber, code }),
  });
}
