/* ============================================================
   SafeGrid Africa — useGeolocation Hook
   Wraps the browser Geolocation API with loading/error state.
   ============================================================ */

import { useState, useEffect, useCallback } from 'react';

const DEFAULT_OPTIONS = {
  enableHighAccuracy: true,
  timeout: 10000,
  maximumAge: 30000, // Accept cached position up to 30s old
};

/**
 * useGeolocation
 * Returns the user's current GPS position with loading and error state.
 *
 * @param {boolean} autoFetch - automatically fetch location on mount
 * @returns {{ position, loading, error, refresh }}
 */
export function useGeolocation(autoFetch = false) {
  const [position, setPosition] = useState(null);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState(null);

  const fetchLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }

    setLoading(true);
    setError(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setPosition({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          timestamp: pos.timestamp,
        });
        setLoading(false);
      },
      (err) => {
        let message = 'Unable to retrieve your location.';
        switch (err.code) {
          case err.PERMISSION_DENIED:
            message = 'Location permission denied. Please enable it in your browser settings.';
            break;
          case err.POSITION_UNAVAILABLE:
            message = 'Location information is unavailable.';
            break;
          case err.TIMEOUT:
            message = 'Location request timed out.';
            break;
          default:
            break;
        }
        setError(message);
        setLoading(false);
      },
      DEFAULT_OPTIONS
    );
  }, []);

  useEffect(() => {
    if (autoFetch) fetchLocation();
  }, [autoFetch, fetchLocation]);

  return { position, loading, error, refresh: fetchLocation };
}

export default useGeolocation;
