/* ============================================================
   SafeGrid Africa — useFilters Hook
   Manages all active filter state and returns filtered datasets.
   ============================================================ */

import { useState, useMemo } from 'react';
import { MOCK_CRIMES } from '../data/mockData';

const DEFAULT_FILTERS = {
  types:    ['All'],
  timeRange: '7d',
  status:   'All',
  severity: 'All',
};

export function useFilters() {
  const [filters, setFilters] = useState(DEFAULT_FILTERS);

  // ── Toggle a single crime type ────────────────────────────
  const toggleType = (type) => {
    setFilters((prev) => {
      if (type === 'All') return { ...prev, types: ['All'] };

      const without = prev.types.filter((t) => t !== 'All' && t !== type);
      const next    = prev.types.includes(type) ? without : [...without, type];
      return { ...prev, types: next.length ? next : ['All'] };
    });
  };

  // ── Set time range ────────────────────────────────────────
  const setTimeRange = (value) => setFilters((prev) => ({ ...prev, timeRange: value }));

  // ── Set status filter ─────────────────────────────────────
  const setStatus = (value) => setFilters((prev) => ({ ...prev, status: value }));

  // ── Set severity filter ───────────────────────────────────
  const setSeverity = (value) => setFilters((prev) => ({ ...prev, severity: value }));

  // ── Reset all filters ─────────────────────────────────────
  const resetFilters = () => setFilters(DEFAULT_FILTERS);

  // ── Derived filtered crimes ───────────────────────────────
  const filteredCrimes = useMemo(() => {
    let data = MOCK_CRIMES;

    // Filter by type
    if (!filters.types.includes('All')) {
      data = data.filter((c) => filters.types.includes(c.type));
    }

    // Filter by time range
    if (filters.timeRange !== 'all') {
      const hoursMap = { '24h': 24, '7d': 168, '30d': 720 };
      const hours    = hoursMap[filters.timeRange] ?? Infinity;
      const cutoff   = new Date(Date.now() - hours * 60 * 60 * 1000);
      data = data.filter((c) => new Date(c.date) >= cutoff);
    }

    // Filter by status
    if (filters.status !== 'All') {
      data = data.filter((c) => c.status === filters.status);
    }

    // Filter by severity
    if (filters.severity !== 'All') {
      data = data.filter((c) => c.severity === filters.severity.toLowerCase());
    }

    return data;
  }, [filters]);

  // ── Active filter count (for badge) ──────────────────────
  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (!filters.types.includes('All'))  count++;
    if (filters.timeRange !== '7d')       count++;
    if (filters.status !== 'All')         count++;
    if (filters.severity !== 'All')       count++;
    return count;
  }, [filters]);

  return {
    filters,
    filteredCrimes,
    activeFilterCount,
    toggleType,
    setTimeRange,
    setStatus,
    setSeverity,
    resetFilters,
  };
}

export default useFilters;
