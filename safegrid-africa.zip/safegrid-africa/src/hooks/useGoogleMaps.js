/* ============================================================
   SafeGrid Africa — useGoogleMaps Hook
   Loads the Google Maps JavaScript API via @googlemaps/js-api-loader.
   INSERT GOOGLE MAPS API KEY HERE — replace the placeholder below.
   ============================================================ */

import { useState, useEffect, useRef } from 'react';
import { Loader } from '@googlemaps/js-api-loader';

// ─────────────────────────────────────────────────────────────
// INSERT GOOGLE MAPS API KEY HERE
// Get your key at: https://console.cloud.google.com/
// Enable: Maps JavaScript API, Geocoding API, Places API
const GOOGLE_MAPS_API_KEY = 'INSERT_YOUR_GOOGLE_MAPS_API_KEY_HERE';
// ─────────────────────────────────────────────────────────────

let loaderInstance = null;

function getLoader() {
  if (!loaderInstance) {
    loaderInstance = new Loader({
      apiKey: GOOGLE_MAPS_API_KEY,
      version: 'weekly',
      libraries: ['places', 'geometry', 'marker'],
    });
  }
  return loaderInstance;
}

/**
 * useGoogleMaps
 * Loads the Maps JS SDK once and returns the google object.
 *
 * @returns {{ google, loaded, error }}
 */
export function useGoogleMaps() {
  const [loaded, setLoaded] = useState(false);
  const [error, setError]   = useState(null);
  const googleRef           = useRef(null);

  useEffect(() => {
    if (window.google?.maps) {
      googleRef.current = window.google;
      setLoaded(true);
      return;
    }

    getLoader()
      .load()
      .then((google) => {
        googleRef.current = google;
        setLoaded(true);
      })
      .catch((err) => {
        console.error('[SafeGrid] Google Maps failed to load:', err);
        setError('Failed to load Google Maps. Check your API key and internet connection.');
      });
  }, []);

  return { google: googleRef.current, loaded, error };
}

export default useGoogleMaps;
