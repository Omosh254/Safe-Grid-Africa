/* ============================================================
   SafeGrid Africa — App.jsx
   Root component. Wires all features together.

   Developer setup checklist:
   1. INSERT GOOGLE MAPS API KEY HERE → src/hooks/useGoogleMaps.js
   2. INSERT BACKEND API ENDPOINT HERE → src/utils/api.js
   3. INSERT AUTH LOGIC HERE → src/utils/api.js + Header.jsx
   4. INSERT IMAGE/ICON URL HERE → public/icons/ (PWA icons)
   ============================================================ */

import React, { useState, useEffect, useCallback, useMemo } from 'react';

import Header        from './components/Header';
import MapComponent  from './components/MapComponent';
import MapControls   from './components/MapControls';
import SidePanel     from './components/SidePanel';
import BottomNav     from './components/BottomNav';
import SafetyScore   from './components/SafetyScore';
import ReportModal   from './components/ReportModal';
import LoadingScreen from './components/LoadingScreen';
import { useToast  } from './components/Toast';
import { useFilters } from './hooks/useFilters';
import useGeolocation from './hooks/useGeolocation';
import { MOCK_ALERTS, MOCK_SPONSORED } from './data/mockData';
import { formatCoords } from './utils/helpers';

// ── useBreakpoint ──────────────────────────────────────────────
function useIsMobile() {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  useEffect(() => {
    const fn = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', fn);
    return () => window.removeEventListener('resize', fn);
  }, []);
  return isMobile;
}

// ── App ───────────────────────────────────────────────────────
function App() {
  // ── State ─────────────────────────────────────────────────
  const [loading,       setLoading    ] = useState(true);
  const [activeTab,     setActiveTab  ] = useState('alerts');
  const [panelOpen,     setPanelOpen  ] = useState(true);
  const [showReport,    setShowReport ] = useState(false);
  const [activeView,    setActiveView ] = useState('map'); // mobile view
  const [userPosition,  setUserPos    ] = useState(null);
  const [locating,      setLocating   ] = useState(false);

  const isMobile  = useIsMobile();
  const { Toasts, info, success, warning, error: toastError } = useToast();
  const { filters, filteredCrimes, activeFilterCount, toggleType, setTimeRange, setStatus, setSeverity, resetFilters } = useFilters();
  const { refresh: getGPS } = useGeolocation(false);

  // ── High-alert count for badges ───────────────────────────
  const highAlertCount = useMemo(
    () => MOCK_ALERTS.filter((a) => a.level === 'high').length,
    []
  );

  // ── Geolocation ───────────────────────────────────────────
  const handleLocate = useCallback(async () => {
    if (!navigator.geolocation) {
      toastError('Geolocation is not supported by your browser.');
      return;
    }
    setLocating(true);
    info('📍 Finding your location…', { duration: 2000 });

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const position = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setUserPos(position);
        // Pan map to user
        window._safegridMapControls?.panTo(position);
        success(`📍 Located: ${formatCoords(position.lat, position.lng)}`);
        setLocating(false);
      },
      (err) => {
        const messages = {
          1: 'Location permission denied. Enable it in browser settings.',
          2: 'Location unavailable. Try again.',
          3: 'Location request timed out.',
        };
        toastError(messages[err.code] || 'Could not determine location.');
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
    );
  }, [info, success, toastError]);

  // ── Navigation (mobile) ───────────────────────────────────
  const handleNavigate = useCallback((view) => {
    if (view === 'report') {
      setShowReport(true);
      return;
    }
    if (view === 'map') {
      setPanelOpen(false);
      setActiveView('map');
      return;
    }
    const tabMap = { alerts: 'alerts', filters: 'filters', sponsored: 'sponsored' };
    if (tabMap[view]) {
      setActiveTab(tabMap[view]);
      setPanelOpen(true);
      setActiveView(view);
    }
  }, []);

  // ── Alert focus — pan map to alert location ───────────────
  const handleAlertFocus = useCallback((alert) => {
    if (alert.lat && alert.lng) {
      window._safegridMapControls?.panTo({ lat: alert.lat, lng: alert.lng });
      if (isMobile) setPanelOpen(false);
      info(`📍 Centred on ${alert.area}`);
    }
  }, [isMobile, info]);

  // ── Sponsor CTA handler ───────────────────────────────────
  const handleSponsorCTA = useCallback((sponsorId) => {
    const sponsor = MOCK_SPONSORED.find((s) => s.id === sponsorId);
    if (sponsor?.website) {
      window.open(sponsor.website, '_blank', 'noopener,noreferrer');
    }
  }, []);

  // ── Side panel on desktop: auto-open ─────────────────────
  useEffect(() => {
    if (!isMobile) setPanelOpen(true);
  }, [isMobile]);

  // ── Install prompt (PWA "Add to Home Screen") ─────────────
  useEffect(() => {
    const handler = (e) => {
      e.preventDefault();
      // Show custom install prompt after 30s
      setTimeout(() => {
        info('📲 Install SafeGrid for quick access!', {
          title: 'Add to Home Screen',
          duration: 8000,
        });
        // Store event for later programmatic trigger
        window._safegridInstallPrompt = e;
      }, 30000);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, [info]);

  // ── Filter props passed into side panel ───────────────────
  const filterProps = {
    filters,
    activeFilterCount,
    toggleType,
    setTimeRange,
    setStatus,
    setSeverity,
    resetFilters,
  };

  // ── Panel open state (mobile + desktop) ──────────────────
  const sidePanelOpen = isMobile ? (panelOpen && activeView !== 'map') : panelOpen;

  // ── Render ────────────────────────────────────────────────
  return (
    <>
      {/* Loading splash */}
      {loading && (
        <LoadingScreen onComplete={() => setLoading(false)} />
      )}

      {/* Main app shell */}
      <div style={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        opacity: loading ? 0 : 1,
        transition: 'opacity 0.3s ease-out',
      }}>

        {/* ── Header ── */}
        <Header
          onAlertsClick={() => {
            setActiveTab('alerts');
            setPanelOpen(true);
            if (isMobile) setActiveView('alerts');
          }}
          onProfileClick={() => {
            // INSERT AUTH LOGIC HERE
          }}
        />

        {/* ── Main content area ── */}
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden', position: 'relative' }}>

          {/* ── Map Layer ── */}
          <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
            <MapComponent
              crimes={filteredCrimes}
              sponsored={MOCK_SPONSORED}
              userPosition={userPosition}
              onReportClick={() => setShowReport(true)}
              onSponsorCTA={handleSponsorCTA}
            />

            {/* ── Map overlays ── */}

            {/* Area label */}
            <div style={{
              position: 'absolute', left: '12px', top: '12px', zIndex: 20,
              background: 'rgba(15,38,84,0.92)',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(0,174,239,0.25)',
              borderRadius: '10px',
              padding: '7px 12px',
            }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '13px', fontWeight: 700 }}>
                Nairobi, Kenya
              </div>
              <div style={{ fontSize: '10px', color: 'var(--text-3)', marginTop: '1px' }}>
                −1.2921°, 36.8219°
              </div>
            </div>

            {/* Safety score */}
            <SafetyScore area="Westlands" />

            {/* Active filters badge */}
            {activeFilterCount > 0 && (
              <div style={{
                position: 'absolute', left: '12px', bottom: isMobile ? '120px' : '76px',
                zIndex: 20,
                background: 'rgba(0,174,239,0.15)',
                backdropFilter: 'blur(12px)',
                border: '1px solid rgba(0,174,239,0.4)',
                borderRadius: '20px',
                padding: '5px 12px',
                fontSize: '11px',
                fontWeight: 700,
                color: 'var(--secondary)',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                cursor: 'pointer',
                animation: 'popIn 0.2s ease-out',
              }}
                onClick={() => {
                  setActiveTab('filters');
                  setPanelOpen(true);
                  if (isMobile) setActiveView('filters');
                }}
              >
                ⚙ {activeFilterCount} filter{activeFilterCount > 1 ? 's' : ''} active
                <span style={{ opacity: 0.7 }}>— {filteredCrimes.length} incidents</span>
              </div>
            )}

            {/* Map controls */}
            <MapControls
              onLocate={handleLocate}
              onTogglePanel={() => setPanelOpen((v) => !v)}
              panelOpen={sidePanelOpen}
              locating={locating}
            />

            {/* FAB row */}
            {!isMobile && (
              <div style={{
                position: 'absolute',
                bottom: '24px',
                left: '50%',
                transform: 'translateX(-50%)',
                zIndex: 20,
                display: 'flex',
                gap: '10px',
              }}>
                <button
                  style={{
                    display: 'flex', alignItems: 'center', gap: '8px',
                    padding: '12px 20px', borderRadius: '20px',
                    background: 'rgba(15,38,84,0.92)',
                    backdropFilter: 'blur(12px)',
                    border: '1px solid rgba(0,174,239,0.32)',
                    color: 'var(--text)', cursor: 'pointer',
                    fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: '13px',
                    boxShadow: '0 4px 20px rgba(0,0,0,0.35)',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(0,174,239,0.15)')}
                  onMouseLeave={(e) => (e.currentTarget.style.background = 'rgba(15,38,84,0.92)')}
                  onClick={() => { setActiveTab('filters'); setPanelOpen(true); }}
                >
                  ⚙ Filters
                  {activeFilterCount > 0 && (
                    <span style={{
                      padding: '1px 6px', borderRadius: '10px',
                      background: 'var(--secondary)',
                      color: 'var(--primary)', fontSize: '10px', fontWeight: 800,
                    }}>{activeFilterCount}</span>
                  )}
                </button>

                <button
                  style={{
                    display: 'flex', alignItems: 'center', gap: '8px',
                    padding: '12px 22px', borderRadius: '20px',
                    background: 'linear-gradient(135deg, var(--danger-dark), var(--danger))',
                    border: 'none',
                    color: 'white', cursor: 'pointer',
                    fontFamily: 'var(--font-body)', fontWeight: 700, fontSize: '14px',
                    boxShadow: '0 4px 20px rgba(255,59,59,0.4)',
                    transition: 'all 0.25s cubic-bezier(0.34,1.56,0.64,1)',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-2px) scale(1.03)';
                    e.currentTarget.style.boxShadow = '0 8px 28px rgba(255,59,59,0.55)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'none';
                    e.currentTarget.style.boxShadow = '0 4px 20px rgba(255,59,59,0.4)';
                  }}
                  onClick={() => setShowReport(true)}
                >
                  🚨 Report Incident
                </button>
              </div>
            )}
          </div>

          {/* ── Side Panel ── */}
          <SidePanel
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            filterProps={filterProps}
            onAlertFocus={handleAlertFocus}
            alertCount={highAlertCount}
            isMobile={isMobile}
            isOpen={sidePanelOpen}
          />

          {/* Backdrop for mobile panel */}
          {isMobile && sidePanelOpen && (
            <div
              style={{
                position: 'absolute', inset: 0, zIndex: 35,
                background: 'rgba(5,12,30,0.5)',
                backdropFilter: 'blur(2px)',
                animation: 'fadeIn 0.2s ease-out',
              }}
              onClick={() => setPanelOpen(false)}
              aria-label="Close panel"
            />
          )}
        </div>

        {/* ── Bottom Nav (mobile only) ── */}
        {isMobile && (
          <BottomNav
            activeView={activeView}
            onNavigate={handleNavigate}
            alertCount={highAlertCount}
          />
        )}
      </div>

      {/* ── Report Modal ── */}
      {showReport && (
        <ReportModal onClose={() => setShowReport(false)} />
      )}

      {/* ── Toast notifications ── */}
      <Toasts />
    </>
  );
}

export default App;
