/* ============================================================
   SafeGrid Africa — Service Worker
   Provides offline support, background sync, and asset caching.
   ============================================================ */

const CACHE_NAME = 'safegrid-v1.0.0';
const RUNTIME_CACHE = 'safegrid-runtime-v1';

// Assets to pre-cache on install (app shell)
const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/static/js/main.chunk.js',
  '/static/js/bundle.js',
  '/static/css/main.chunk.css',
  '/manifest.json',
  // INSERT ICON URLS HERE — add all icon paths from /public/icons/
];

// ── INSTALL ──────────────────────────────────────────────────
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting())
  );
});

// ── ACTIVATE ─────────────────────────────────────────────────
// Delete old caches on activation
self.addEventListener('activate', (event) => {
  const currentCaches = [CACHE_NAME, RUNTIME_CACHE];
  event.waitUntil(
    caches
      .keys()
      .then((cacheNames) =>
        cacheNames.filter((name) => !currentCaches.includes(name))
      )
      .then((cachesToDelete) =>
        Promise.all(cachesToDelete.map((cache) => caches.delete(cache)))
      )
      .then(() => self.clients.claim())
  );
});

// ── FETCH — Network-first with Cache Fallback ─────────────────
self.addEventListener('fetch', (event) => {
  // Skip non-GET and chrome-extension requests
  if (event.request.method !== 'GET') return;
  if (event.request.url.startsWith('chrome-extension')) return;

  // For Google Maps API calls — network only (no caching)
  if (event.request.url.includes('maps.googleapis.com')) {
    return; // Let the browser handle normally
  }

  // For API calls — network first, fall back gracefully
  // INSERT BACKEND API ENDPOINT HERE — match your domain
  if (event.request.url.includes('/api/')) {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          // Cache successful API responses briefly
          const responseClone = response.clone();
          caches.open(RUNTIME_CACHE).then((cache) => {
            cache.put(event.request, responseClone);
          });
          return response;
        })
        .catch(() =>
          caches.match(event.request).then(
            (cached) =>
              cached ||
              new Response(
                JSON.stringify({ error: 'Offline — cached data unavailable' }),
                { headers: { 'Content-Type': 'application/json' } }
              )
          )
        )
    );
    return;
  }

  // For all other requests — stale-while-revalidate
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      const fetchPromise = fetch(event.request).then((networkResponse) => {
        caches.open(RUNTIME_CACHE).then((cache) => {
          cache.put(event.request, networkResponse.clone());
        });
        return networkResponse;
      });
      return cachedResponse || fetchPromise;
    })
  );
});

// ── BACKGROUND SYNC — Queue offline incident reports ──────────
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-incident-reports') {
    event.waitUntil(syncPendingReports());
  }
});

async function syncPendingReports() {
  // INSERT BACKEND API ENDPOINT HERE
  // Read pending reports from IndexedDB and POST them
  // const db = await openDB('safegrid-offline', 1);
  // const pending = await db.getAll('pendingReports');
  // for (const report of pending) {
  //   await fetch('/api/incidents', { method: 'POST', body: JSON.stringify(report) });
  //   await db.delete('pendingReports', report.id);
  // }
  console.log('[SafeGrid SW] Background sync: pending reports would be synced here');
}

// ── PUSH NOTIFICATIONS ────────────────────────────────────────
self.addEventListener('push', (event) => {
  if (!event.data) return;

  const data = event.data.json();
  const options = {
    body: data.body || 'New safety alert in your area.',
    icon: '/icons/icon-192x192.png',
    badge: '/icons/badge-72x72.png',
    vibrate: [200, 100, 200],
    data: { url: data.url || '/' },
    actions: [
      { action: 'view', title: 'View on Map' },
      { action: 'dismiss', title: 'Dismiss' },
    ],
    tag: 'safegrid-alert',
    renotify: true,
  };

  event.waitUntil(
    self.registration.showNotification(
      data.title || '🚨 SafeGrid Alert',
      options
    )
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  if (event.action === 'dismiss') return;

  event.waitUntil(
    clients
      .matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        const targetUrl = event.notification.data?.url || '/';
        for (const client of clientList) {
          if (client.url === targetUrl && 'focus' in client) {
            return client.focus();
          }
        }
        return clients.openWindow(targetUrl);
      })
  );
});
